<?php
$f = __DIR__ . '/ig-scrape.php';

$php = <<<'PHP'
<?php
require __DIR__ . '/config.php';
require_login();
$pageTitle = 'Scrape Instagram';
$active    = 'ig-scrape';
require_once __DIR__ . '/includes/ScrapeCreators.php';

$uid = (int)(current_user()['id'] ?? 0);
$error = ''; $result = null;
$preHandle = trim($_GET['handle'] ?? '');
$preMitra  = trim($_GET['mitra'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $handle = ltrim(trim($_POST['handle'] ?? ''), '@');
    $mitra  = trim($_POST['mitra_name'] ?? '');
    if ($handle === '') { $error = 'Handle Instagram wajib diisi'; }
    elseif (!preg_match('#^[A-Za-z0-9_.]+$#', $handle)) { $error = 'Format handle tidak valid'; }
    else {
        $sc = new ScrapeCreators();
        $prof = $sc->igProfile($handle);
        if ($prof === null) { $error = 'Gagal ambil profil Instagram.'; }
        else {
            $stats = ScrapeCreators::igUserStats($prof);
            $user = $prof['user'] ?? $prof;
            $igUserId = (string)($user['id'] ?? '');
            $igUser = (string)($user['username'] ?? $handle);
            $fullName = (string)($user['full_name'] ?? $handle);
            $existingIds = [];
            $s = db()->prepare('SELECT ig_post_id FROM ig_posts WHERE ig_username = ? AND user_id = ?');
            $s->execute([$igUser, $uid]);
            foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $pid) { $existingIds[$pid] = true; }
            $fetched = $sc->fetchAllIgPosts($handle, ['stopOnExisting' => count($existingIds) > 0, 'existingIds' => $existingIds]);
            $posts = $fetched['posts'];
            if (count($posts) === 0) { $error = 'Tidak ada post yang berhasil diambil.'; }
            else {
                $inserted = 0; $updated = 0; $totalLikes = 0; $totalPlays = 0;
                $ins = db()->prepare('INSERT INTO ig_posts (user_id,ig_post_id,shortcode,url,ig_user_id,ig_username,mitra_name,media_type,caption,cover_url,taken_at,like_count,comment_count,play_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE shortcode=VALUES(shortcode),url=VALUES(url),mitra_name=VALUES(mitra_name),caption=VALUES(caption),cover_url=VALUES(cover_url),like_count=VALUES(like_count),comment_count=VALUES(comment_count),play_count=VALUES(play_count)');
                foreach ($posts as $p) {
                    $postId = (string)($p['id'] ?? ''); if ($postId === '') continue;
                    $shortcode = (string)($p['code'] ?? '');
                    $mediaType = (int)($p['media_type'] ?? 1);
                    $caption = (string)($p['caption']['text'] ?? '');
                    $takenAt = (int)($p['taken_at'] ?? 0);
                    $likeCount = (int)($p['like_count'] ?? 0);
                    $commentCnt = (int)($p['comment_count'] ?? 0);
                    $playCount = (int)($p['play_count'] ?? 0);
                    $coverUrl = (string)($p['display_uri'] ?? '');
                    $url = $shortcode ? 'https://www.instagram.com/p/'.$shortcode : '';
                    $totalLikes += $likeCount; $totalPlays += $playCount;
                    $ins->execute([$uid,$postId,$shortcode,$url,$igUserId,$igUser,$mitra,$mediaType,$caption,$coverUrl,$takenAt,$likeCount,$commentCnt,$playCount]);
                    $rc = $ins->rowCount(); if ($rc===1) $inserted++; elseif ($rc===2) $updated++;
                }
                db()->prepare('INSERT INTO ig_scrapes (user_id,handle,mitra_name,ig_user_id,ig_username,total_posts,total_likes,total_plays,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?,?)')->execute([$uid,$handle,$mitra,$igUserId,$igUser,count($posts),$totalLikes,$totalPlays,(int)$fetched['credits'],'success',null]);
                $result = ['handle'=>$handle,'mitra'=>$mitra,'full_name'=>$fullName,'ig_user'=>$igUser,'followers'=>$stats['followers_count'],'profile_posts'=>$stats['posts_count'],'fetched'=>count($posts),'inserted'=>$inserted,'updated'=>$updated,'total_likes'=>$totalLikes,'total_plays'=>$totalPlays,'pages'=>(int)$fetched['pages'],'credits'=>(int)$fetched['credits'],'complete'=>(bool)$fetched['complete'],'stopped_early'=>(bool)($fetched['stopped_early']??false)];
            }
        }
    }
}

$scopeWhere = ''; $scopeParams = [];
if (!is_admin()) { $scopeWhere = ' AND s.user_id = ?'; $scopeParams[] = $uid; }
$stmt = db()->prepare("SELECT s.*, u.username FROM ig_scrapes s JOIN users u ON u.id = s.user_id WHERE 1=1 $scopeWhere ORDER BY s.created_at DESC LIMIT 20");
$stmt->execute($scopeParams);
$history = $stmt->fetchAll();

$mitraRows = db()->query("SELECT id, nama, produk, COALESCE(instagram_handle,'') AS ig_handle FROM mitra WHERE nama != '' ORDER BY produk, nama")->fetchAll(PDO::FETCH_ASSOC);
$brandGroups = [];
$igAccounts = [];
foreach ($mitraRows as $m) {
    $brand = $m['produk'] !== '' ? $m['produk'] : 'Tanpa Brand';
    $brandGroups[$brand][] = $m;
    if ($m['ig_handle'] !== '') { $igAccounts[] = $m; }
}

require __DIR__ . '/layouts/header.php';
PHP;

file_put_contents($f, $php);
echo "PHP: " . strlen($php) . "\n";
