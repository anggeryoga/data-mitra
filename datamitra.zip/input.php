<?php
/**
 * input.php — Input link video TikTok satuan, ditarik datanya via TikWM.
 * Field: Nama Mitra (opsional) + link video. Hasil tersimpan dengan user_id pemilik.
 */
require __DIR__ . '/config.php';
require_login();

$pageTitle = 'Input Video';
$active    = 'input';

require_once __DIR__ . '/includes/TikWM.php';

$uid   = (int)(current_user()['id'] ?? 0);
$error = '';
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    $url   = trim($_POST['url'] ?? '');
    $mitra = trim($_POST['mitra_name'] ?? '');

    if ($url === '') {
        $error = 'Link video TikTok wajib diisi';
    } elseif (!preg_match('#tiktok\.com/#i', $url)) {
        $error = 'Link yang dimasukkan bukan link TikTok';
    } else {
        // Normalisasi: kalau short link, follow redirect untuk dapat aweme_id
        $api = new TikWM();
        try {
            // Rate limit TikWM gratis: 1 req/detik. Jeda biar aman untuk batch.
            if (!empty($_SESSION['last_tiktok_api'])) {
                $elapsed = microtime(true) - (float)$_SESSION['last_tiktok_api'];
                if ($elapsed < 1.05) {
                    usleep((int)((1.05 - $elapsed) * 1_000_000));
                }
            }
            $data = $api->getVideo($url);
            $_SESSION['last_tiktok_api'] = microtime(true);

            $aweme = (string)($data['id'] ?? '');
            if ($aweme === '') {
                $error = 'Gagal membaca ID video dari link. Pastikan link video yang valid.';
            } else {
                $authorUid  = (string)($data['author']['unique_id'] ?? '');
                $authorNick = (string)($data['author']['nickname'] ?? '');
                $createTime = (int)($data['create_time'] ?? 0);
                $title      = (string)($data['title'] ?? '');

                // Cek duplikat aweme_id
                $stmt = db()->prepare('SELECT id, user_id FROM videos WHERE aweme_id = ?');
                $stmt->execute([$aweme]);
                $dup = $stmt->fetch();

                $fields = [
                    $url, $authorUid, $authorNick, $mitra, $title,
                    $createTime,
                    (int)($data['play_count'] ?? 0),
                    (int)($data['digg_count'] ?? 0),
                    (int)($data['comment_count'] ?? 0),
                    (int)($data['share_count'] ?? 0),
                ];

                if ($dup) {
                    $owner = (int)$dup['user_id'];
                    if ($owner === $uid || is_admin()) {
                        // Update (refresh angka terbaru)
                        db()->prepare('
                            UPDATE videos SET
                                url=?, author_unique_id=?, author_nickname=?, mitra_name=?, title=?,
                                create_time=?, play_count=?, digg_count=?, comment_count=?, share_count=?
                            WHERE aweme_id=?
                        ')->execute(array_merge($fields, [$aweme]));
                        $success = '@' . $authorUid . ' — data diperbarui (' . format_number((int)($data['play_count'] ?? 0)) . ' views)';
                    } else {
                        $error = 'Video ini sudah di-input oleh user lain.';
                    }
                } else {
                    db()->prepare('
                        INSERT INTO videos
                            (user_id, aweme_id, url, author_unique_id, author_nickname, mitra_name, title, cover_url, create_time, play_count, digg_count, comment_count, share_count)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ')->execute([
                        $uid, $aweme, $url, $authorUid, $authorNick, $mitra, $title, '',
                        $createTime,
                        (int)($data['play_count'] ?? 0),
                        (int)($data['digg_count'] ?? 0),
                        (int)($data['comment_count'] ?? 0),
                        (int)($data['share_count'] ?? 0),
                    ]);
                    $success = '@' . $authorUid . ' — berhasil disimpan (' . format_number((int)($data['play_count'] ?? 0)) . ' views, ' . format_number((int)($data['digg_count'] ?? 0)) . ' likes)';
                }
            }
        } catch (Throwable $ex) {
            $error = 'Gagal ambil data: ' . $ex->getMessage();
        }
    }
}

// Daftar video yang baru di-input (scope sesuai role)
$scopeWhere  = '';
$scopeParams = [];
if (!is_admin()) {
    $scopeWhere  = ' AND v.user_id = ?';
    $scopeParams[] = $uid;
}
$stmt = db()->prepare("
    SELECT v.*, u.username
    FROM videos v JOIN users u ON u.id = v.user_id
    WHERE 1=1 $scopeWhere
    ORDER BY v.created_at DESC
    LIMIT 30
");
$stmt->execute($scopeParams);
$recent = $stmt->fetchAll();

require __DIR__ . '/layouts/header.php';
?>

<div class="grid-2">
    <div class="card">
        <h2 class="card-title">Input Video Satuan</h2>
        <p class="card-desc">Untuk nambah satu video spesifik. Di sini pakai <strong>TikWM</strong> (gratis, per-link). Kalau mau narik satu akun utuh, pakai <a href="scrape.php">Scrape Akun</a>.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <form method="post" action="input.php">
            <?= csrf_field() ?>
            <div class="form-group">
                <label for="mitra_name">Nama Mitra</label>
                <?= mitra_select(mitra_names()) ?>
                <input type="text" id="mitra_name" name="mitra_name" class="form-control"
                       placeholder="Atau ketik mitra baru…"
                       value="<?= e($_POST['mitra_name'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label for="url">Link Video TikTok</label>
                <input type="text" id="url" name="url" class="form-control" required
                       placeholder="https://www.tiktok.com/@user/video/1234567890">
                <small class="form-hint">Bisa link full atau short link. Contoh: <code>https://vt.tiktok.com/...</code></small>
            </div>
            <button type="submit" class="btn btn-primary" id="btn-submit">Ambil Data</button>
        </form>
    </div>

    <div class="card">
        <h2 class="card-title">Video Baru Di-input</h2>
        <?php if (count($recent) === 0): ?>
            <div class="empty">Belum ada video.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Video</th>
                        <th>Akun</th>
                        <th class="ta-right">Views</th>
                        <th class="ta-right">Likes</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($recent as $r): ?>
                    <tr>
                        <td>
                            <a href="<?= e($r['url']) ?>" target="_blank" rel="noopener" class="cell-primary">
                                <?= e(mb_strimwidth((string)($r['title'] ?: '(tanpa deskripsi)'), 0, 48, '…')) ?>
                            </a>
                        </td>
                        <td>
                            <strong>@<?= e($r['author_unique_id']) ?></strong>
                            <?php if ($r['mitra_name'] !== ''): ?>
                                <div class="cell-sub"><?= e($r['mitra_name']) ?></div>
                            <?php endif; ?>
                            <div class="cell-sub"><?= e(date('d M Y', (int)$r['create_time'])) ?> · by <?= e($r['username']) ?></div>
                        </td>
                        <td class="ta-right"><strong><?= format_number((int)$r['play_count']) ?></strong></td>
                        <td class="ta-right"><?= format_number((int)$r['digg_count']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script>
(function() {
    var mitraSel = document.getElementById('mitra-select');
    var mitraInput = document.getElementById('mitra_name');
    if (mitraSel && mitraInput) {
        mitraSel.addEventListener('change', function() {
            if (this.value) { mitraInput.value = this.value; }
        });
    }
    document.querySelector('form[action="input.php"]').addEventListener('submit', function() {
        var b = document.getElementById('btn-submit');
        b.disabled = true;
        b.textContent = 'Mengambil data...';
    });
})();
</script>

<?php require __DIR__ . '/layouts/footer.php'; ?>