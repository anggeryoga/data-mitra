-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: tiktok_analytics
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mitra`
--

DROP TABLE IF EXISTS `mitra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mitra` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `nama` varchar(128) NOT NULL DEFAULT '',
  `produk` varchar(128) NOT NULL DEFAULT '',
  `tiktok_handle` varchar(128) NOT NULL DEFAULT '',
  `tiktok_url` varchar(512) NOT NULL DEFAULT '',
  `instagram_url` varchar(512) NOT NULL DEFAULT '',
  `alamat` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mitra_handle` (`tiktok_handle`),
  KEY `idx_mitra_user` (`user_id`),
  KEY `idx_mitra_handle` (`tiktok_handle`),
  KEY `idx_mitra_produk` (`produk`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mitra`
--

LOCK TABLES `mitra` WRITE;
/*!40000 ALTER TABLE `mitra` DISABLE KEYS */;
INSERT INTO `mitra` VALUES (1,0,'Angger Wahyu Ade Saputra','Be Nice Coffee','benicecoffeecikarang','https://www.tiktok.com/@benicecoffeecikarang','https://www.instagram.com/benicecoffeecikarang/','Kontrakan Pak Pram No 4, Jalan Untung Suropati, RT.2/RW.4, Kampung Cibeureum, Cikarang Utara (Kontrakan No 4 Warna Biru), KAB. BEKASI, CIKARANG UTARA, JAWA BARAT, ID, 17831 CIKARANG JAWA BARAT','2026-09-18 02:23:26'),(2,0,'Sri wahyuni','Be Nice Coffee','','','','Toto Tentrem Rt 14 Rw 04 Bangunsari Kec. Dolopo Madiun, MADIUN JAWA TIMUR','2026-09-18 02:23:26'),(3,0,'salwa athiyah azzahra','Be Nice Coffee','benicetamanraya.tng','https://www.tiktok.com/@benicetamanraya.tng','https://www.instagram.com/benicetamanraya.tng','Kp Berusaha, Desa Banyu Asih RT.002/001, Kec. Mauk, Kab. Tangerang, No Rumah 40, Tangerang Banten INDONESIA','2026-09-18 02:23:26'),(4,0,'Nor Raniah','Be Nice Coffee','be_nice_coffee_sukamara','https://www.tiktok.com/@be_nice_coffee_sukamara','https://www.instagram.com/be_nice_coffee_sukamara','Jln Pasir Panjang RT 3 No Rumah 153, Desa Sungai Tabuk, Kec. Pantai Lunci, Kab. Sukamara, Kalimantan Tengah, Kode Pos 74775','2026-09-18 02:23:26'),(5,0,'Gustika Wahyu Pratama','Be Nice Coffee','gusti.wapra','https://www.tiktok.com/@gusti.wapra','','Dsn. Podang, Kel. Lajo Lor, Kec. Singgahan, Kab. Tuban, TUBAN JAWA TIMUR','2026-09-18 02:23:26'),(6,0,'Agis Setya','Be Nice Coffee','benicecoffesukun','https://www.tiktok.com/@benicecoffesukun','https://www.instagram.com/benicecoffesukun1/','Jln Terusan Mergan Lori No 14, Tanjung Rejo, Outlet Be Nice Coffee Sukun, Kota Malang','2026-09-18 02:23:26'),(7,0,'','Be Nice Coffee','benicecoffee.gokuah_trb','https://www.tiktok.com/@benicecoffee.gokuah_trb','https://www.instagram.com/benicecoffee_trubus/','Jln Trubus, Bangka Tengah, Kec. Lubuk Besar','2026-09-18 02:23:26'),(8,0,'Dedy Tri w','Be Nice Coffee','benicecoffee.kajen','https://www.tiktok.com/@benicecoffee.kajen','https://www.instagram.com/benicecoffee_kajen/','Jln Teuku Umar, Sumurbandung, Gejlig, Kec. Kajen, Kab. Pekalongan, Jawa Tengah (Utara SPBU Kajen)','2026-09-18 02:23:26');
/*!40000 ALTER TABLE `mitra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scrapes`
--

DROP TABLE IF EXISTS `scrapes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scrapes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `handle` varchar(128) NOT NULL,
  `mitra_name` varchar(128) NOT NULL DEFAULT '',
  `author_unique_id` varchar(128) NOT NULL DEFAULT '',
  `author_nickname` varchar(128) NOT NULL DEFAULT '',
  `total_videos` int(10) unsigned NOT NULL DEFAULT 0,
  `total_views` int(10) unsigned NOT NULL DEFAULT 0,
  `credits_used` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('success','error') NOT NULL DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_scrapes_handle` (`handle`),
  KEY `idx_scrapes_user` (`user_id`),
  CONSTRAINT `fk_scrapes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scrapes`
--

LOCK TABLES `scrapes` WRITE;
/*!40000 ALTER TABLE `scrapes` DISABLE KEYS */;
INSERT INTO `scrapes` VALUES (1,1,'benicecoffeecikarang','','benicecoffeecikarang','Be Nice Coffee cikarang',42,48702,5,'success',NULL,'2026-09-18 01:50:19'),(2,1,'benicecoffeecikarang','Benice Coffee Cikarang','benicecoffeecikarang','Be Nice Coffee cikarang',42,48702,5,'success',NULL,'2026-09-18 02:09:45'),(3,1,'benicecoffeecikarang','Benice Coffee Cikarang','benicecoffeecikarang','Be Nice Coffee cikarang',10,19923,1,'success',NULL,'2026-09-18 02:43:52');
/*!40000 ALTER TABLE `scrapes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT '',
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$eFmJ8IKaMaSMyt1kZi2LLOTwqDf1BHDeNx9qjyX2IwWYhNLzgwt0G','Administrator','admin',1,'2026-09-18 01:37:36'),(2,'user1','$2y$10$8AuQWo30cuzOls3KZltJne2.MW/HJLOA6AqILRZGt7eOKWSxZnrHy','User Satu','user',1,'2026-09-18 01:37:36'),(3,'user2','$2y$10$1jNdqzRtVyhBxnX3XcGtBO6BpB6M119MxpXLy08ZeTwlzpDjyeY2.','User Dua','user',1,'2026-09-18 01:37:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `aweme_id` varchar(64) NOT NULL,
  `url` varchar(512) NOT NULL,
  `author_unique_id` varchar(128) NOT NULL DEFAULT '',
  `author_nickname` varchar(128) NOT NULL DEFAULT '',
  `mitra_name` varchar(128) NOT NULL DEFAULT '',
  `title` text DEFAULT NULL,
  `cover_url` varchar(512) DEFAULT '',
  `create_time` int(10) unsigned NOT NULL,
  `play_count` int(10) unsigned NOT NULL DEFAULT 0,
  `digg_count` int(10) unsigned NOT NULL DEFAULT 0,
  `comment_count` int(10) unsigned NOT NULL DEFAULT 0,
  `share_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_videos_aweme` (`aweme_id`),
  KEY `idx_videos_author` (`author_unique_id`),
  KEY `idx_videos_user` (`user_id`),
  KEY `idx_videos_create_time` (`create_time`),
  KEY `idx_videos_mitra` (`mitra_name`),
  CONSTRAINT `fk_videos_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (2,1,'7651592962220281108','https://www.tiktok.com/@benicecoffeecikarang/video/7651592962220281108','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Ga ada cita” jualan kopi tapi kita bisa #benicecoffee #cikarang #pasirgombong ','',1781525320,3228,44,4,1,'2026-09-18 01:50:19'),(3,1,'7663888746902850837','https://www.tiktok.com/@benicecoffeecikarang/video/7663888746902850837','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Kesibukan malam minggu #benicecoffee #cikarang #pasirgombong ','',1784388155,10659,31,5,3,'2026-09-18 01:50:19'),(4,1,'7678665728014257426','https://www.tiktok.com/@benicecoffeecikarang/video/7678665728014257426','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','ngga boleh galak galak ya!!! #benicecoffee #minumanviral #fyp #pasirgombongcikarang ','',1787828690,1884,24,0,1,'2026-09-18 01:50:19'),(5,1,'7677793120427216136','https://www.tiktok.com/@benicecoffeecikarang/video/7677793120427216136','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','yuk mampir ke be nice coffee cikarang #pasirgombongcikarang #benicecoffee #fyp #coffee #minumanviral ','',1787625523,379,10,0,0,'2026-09-18 01:50:19'),(6,1,'7677031210903670024','https://www.tiktok.com/@benicecoffeecikarang/video/7677031210903670024','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','yang belum nyoba ayo merapat #benicecoffee #fyp #pasirgombongcikarang #kulinercikarang ','',1787448127,1010,16,0,0,'2026-09-18 01:50:19'),(7,1,'7676769725761998098','https://www.tiktok.com/@benicecoffeecikarang/video/7676769725761998098','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','malem minggu jangan lupa mampir, banyak pilihan dan ngga bikin bosan #kulinercikarang #pasirgombongcikarang #fyp #benicecoffee ','',1787387246,526,14,0,1,'2026-09-18 01:50:19'),(8,1,'7675729064854064404','https://www.tiktok.com/@benicecoffeecikarang/photo/7675729064854064404','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Menerima pesanan #pasirgombong #kopi','',1787144944,366,5,0,1,'2026-09-18 01:50:19'),(9,1,'7674569472665013522','https://www.tiktok.com/@benicecoffeecikarang/video/7674569472665013522','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','cara mengatasi pegal setelah kerja #CapCut #benicecoffee #coffee #pasirgombongcikarang  #kulinercikarang ','',1786874959,434,12,2,0,'2026-09-18 01:50:19'),(10,1,'7674421157411458312','https://www.tiktok.com/@benicecoffeecikarang/video/7674421157411458312','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','lagian di suruh putar otak #cikarang #pestakulinermerdeka #fyp #pasirgombongcikarang #benicecoffee ','',1786840429,719,19,2,0,'2026-09-18 01:50:19'),(11,1,'7673481794871692564','https://www.tiktok.com/@benicecoffeecikarang/video/7673481794871692564','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Dalgona #benicecoffee #pasirgombong ','',1786621712,718,8,0,2,'2026-09-18 01:50:19'),(12,1,'7672641137059859730','https://www.tiktok.com/@benicecoffeecikarang/video/7672641137059859730','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','jangan lupa mampir di Be Nice Coffee cikarang  #benicecoffee #pasirgombongcikarang #fyp #cikarang ','',1786425985,844,8,0,0,'2026-09-18 01:50:19'),(13,1,'7672324532421676308','https://www.tiktok.com/@benicecoffeecikarang/video/7672324532421676308','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Membalas @Kanggrafir ','',1786352277,246,10,0,0,'2026-09-18 01:50:19'),(14,1,'7672002818609351954','https://www.tiktok.com/@benicecoffeecikarang/video/7672002818609351954','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','beli 2 gratis photo booth bestt #kopi #benicecoffee #cikarang #pasirgombongcikarang ','',1786277361,657,15,3,2,'2026-09-18 01:50:19'),(15,1,'7671544261975837973','https://www.tiktok.com/@benicecoffeecikarang/video/7671544261975837973','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Mulai malam ini 8 agustus #benicecoffee #pasirgombong #cikarang ','',1786170593,816,20,0,3,'2026-09-18 01:50:19'),(16,1,'7671541255511346452','https://www.tiktok.com/@benicecoffeecikarang/photo/7671541255511346452','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Ramaikan !!','',1786169895,419,13,0,1,'2026-09-18 01:50:19'),(17,1,'7670537187917630741','https://www.tiktok.com/@benicecoffeecikarang/video/7670537187917630741','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','#benicecoffee #pasirgombong ','',1785936116,735,23,0,0,'2026-09-18 01:50:19'),(18,1,'7669441469446475029','https://www.tiktok.com/@benicecoffeecikarang/video/7669441469446475029','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Semangat sepanjang hari #benicecoffee #pasirgombong #cikarang ','',1785680999,422,10,0,0,'2026-09-18 01:50:19'),(19,1,'7669241264604204308','https://www.tiktok.com/@benicecoffeecikarang/video/7669241264604204308','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Matursuwun gusti #benicecoffee #pasirgombong #cikarang ','',1785634389,412,9,0,0,'2026-09-18 01:50:19'),(20,1,'7669090049677380884','https://www.tiktok.com/@benicecoffeecikarang/photo/7669090049677380884','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Temani sepimu bersama satu gelas coffe #benicecoffee #pasirgombong #cikarang ','',1785599182,851,16,0,0,'2026-09-18 01:50:19'),(21,1,'7669075526832672020','https://www.tiktok.com/@benicecoffeecikarang/video/7669075526832672020','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Kurang ngopi maseh #benicecoffee #pasirgombong #cikarang ','',1785595796,683,14,0,1,'2026-09-18 01:50:19'),(22,1,'7665351966821715208','https://www.tiktok.com/@benicecoffeecikarang/video/7665351966821715208','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','#promomakanharian #benicecoffee #promomakangajian #cikarang #pasarbersihcikarang ','',1784728837,335,10,2,0,'2026-09-18 01:50:19'),(23,1,'7664019127815671061','https://www.tiktok.com/@benicecoffeecikarang/photo/7664019127815671061','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Masih banyak menu lainya #benicecoffee #pasirgombong #pecintacoffe ','',1784418512,2578,26,8,8,'2026-09-18 01:50:19'),(24,1,'7662669683094490375','https://www.tiktok.com/@benicecoffeecikarang/video/7662669683094490375','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','temani harimu dengan 1 cup be nice coffee #benicecoffee #cikarang #minumanviral #kopi #fyp ','',1784104321,300,7,0,0,'2026-09-18 01:50:19'),(25,1,'7662400367539326226','https://www.tiktok.com/@benicecoffeecikarang/video/7662400367539326226','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','siap menemani segala urusanmu #kopi #benicecoffee #cikarang ','',1784041620,1267,23,2,3,'2026-09-18 01:50:19'),(26,1,'7661297605091052820','https://www.tiktok.com/@benicecoffeecikarang/video/7661297605091052820','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Makasih best sudah mampir #benicecoffee #cikarang #pasirgombong ','',1783784860,617,20,2,0,'2026-09-18 01:50:19'),(27,1,'7660889979270221077','https://www.tiktok.com/@benicecoffeecikarang/video/7660889979270221077','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','#benicecoffee #cikarang #pasirgombong ','',1783689950,248,6,0,0,'2026-09-18 01:50:19'),(28,1,'7660828569303518485','https://www.tiktok.com/@benicecoffeecikarang/video/7660828569303518485','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Minuman ala cafe #benicecoffee #cikarang ','',1783675652,1311,12,1,0,'2026-09-18 01:50:19'),(29,1,'7660797314520452372','https://www.tiktok.com/@benicecoffeecikarang/video/7660797314520452372','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','#benicecoffee #cikarang ','',1783668381,358,11,0,0,'2026-09-18 01:50:19'),(30,1,'7656381954702527765','https://www.tiktok.com/@benicecoffeecikarang/video/7656381954702527765','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Pusing ? Minimal ngopi #benicecoffee #cikarang #pasirgombong ','',1782640344,428,8,3,0,'2026-09-18 01:50:19'),(31,1,'7653536164565044501','https://www.tiktok.com/@benicecoffeecikarang/video/7653536164565044501','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Kedai abu umar pasir gombong #benicecoffee #cikarang #pasirgombong ','',1781977758,1439,14,5,0,'2026-09-18 01:50:19'),(32,1,'7653531493439933717','https://www.tiktok.com/@benicecoffeecikarang/video/7653531493439933717','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Bisa mampir ke kedai lur,DO khusus malam minggu saja ya #benicecoffee #cikarang #pasirgombong ','',1781976669,859,12,0,1,'2026-09-18 01:50:19'),(33,1,'7653524202292645140','https://www.tiktok.com/@benicecoffeecikarang/photo/7653524202292645140','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Izin post ya kaka #benicecoffee #cikarang ','',1781974977,892,10,0,0,'2026-09-18 01:50:19'),(34,1,'7652268649331576085','https://www.tiktok.com/@benicecoffeecikarang/video/7652268649331576085','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Banyak menu coffe & non coffee #benicecoffee #cikarang ','',1781682642,659,13,0,1,'2026-09-18 01:50:19'),(35,1,'7651574786534952212','https://www.tiktok.com/@benicecoffeecikarang/video/7651574786534952212','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Abaikan muka seriusku #benicecoffee #cikarang #pasirgombong ','',1781521089,869,13,0,0,'2026-09-18 01:50:19'),(36,1,'7650484404032245013','https://www.tiktok.com/@benicecoffeecikarang/photo/7650484404032245013','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Terimakasih udah mampir #benicecoffee #cikarang #pasirgombong','',1781267218,1101,19,0,3,'2026-09-18 01:50:19'),(37,1,'7650141669035216148','https://www.tiktok.com/@benicecoffeecikarang/video/7650141669035216148','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Ngopi ala cafe start from 5k saja #benicecoffee #cikarang ','',1781187414,1328,20,0,1,'2026-09-18 01:50:19'),(38,1,'7650120285395504405','https://www.tiktok.com/@benicecoffeecikarang/video/7650120285395504405','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Banyak menu baru #benicecoffee #cikarang ','',1781182435,873,12,0,0,'2026-09-18 01:50:19'),(39,1,'7650119815507578132','https://www.tiktok.com/@benicecoffeecikarang/video/7650119815507578132','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','ngopi nya di be nice coffe #benicecoffee #cikarang #','',1781182329,1563,30,0,1,'2026-09-18 01:50:19'),(40,1,'7648949383764970773','https://www.tiktok.com/@benicecoffeecikarang/photo/7648949383764970773','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Membalas @Jane 🫧 ','',1780909817,1783,8,0,2,'2026-09-18 01:50:19'),(41,1,'7648669675722788116','https://www.tiktok.com/@benicecoffeecikarang/video/7648669675722788116','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Khusus malam minggu kita buka DO #benicecoffee #cikarang ','',1780844689,1625,14,0,1,'2026-09-18 01:50:19'),(42,1,'7648647078146542869','https://www.tiktok.com/@benicecoffeecikarang/photo/7648647078146542869','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','Pasir gombong kedai bang umar #benicecoffee #cikarang','',1780839429,976,6,2,1,'2026-09-18 01:50:19'),(43,1,'7647456508329905415','https://www.tiktok.com/@benicecoffeecikarang/video/7647456508329905415','benicecoffeecikarang','Be Nice Coffee cikarang','Benice Coffee Cikarang','grand opening Be Nice Coffee cikarang pasir gombong jum\'at jam 13:00 Wib. spesiap promo beli 2 gratis 1. Harga mulai dari 5k. jangan lewatkan promonya ','',1780562231,1287,12,1,7,'2026-09-18 01:50:19');
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tiktok_analytics'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-18 10:18:37
