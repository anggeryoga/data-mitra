-- ============================================================
-- Instagram Support: instagram_handle + ig_posts + ig_scrapes
-- ============================================================

SET NAMES utf8mb4;

-- Tambah instagram_handle di mitra
ALTER TABLE mitra
    ADD COLUMN instagram_handle VARCHAR(128) NOT NULL DEFAULT '' AFTER instagram_url,
    ADD INDEX idx_mitra_ig_handle (instagram_handle);

-- Tabel IG posts (mirip videos tapi untuk Instagram)
CREATE TABLE IF NOT EXISTS ig_posts (
    id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    ig_post_id VARCHAR(64) NOT NULL,
    shortcode VARCHAR(32) NOT NULL DEFAULT '',
    url VARCHAR(512) NOT NULL DEFAULT '',
    ig_user_id VARCHAR(64) NOT NULL DEFAULT '',
    ig_username VARCHAR(128) NOT NULL DEFAULT '',
    mitra_name VARCHAR(128) NOT NULL DEFAULT '',
    media_type TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=photo, 2=video, 8=carousel',
    caption TEXT,
    cover_url VARCHAR(512) DEFAULT NULL,
    taken_at INT(10) UNSIGNED NOT NULL DEFAULT 0,
    like_count INT(10) UNSIGNED NOT NULL DEFAULT 0,
    comment_count INT(10) UNSIGNED NOT NULL DEFAULT 0,
    play_count INT(10) UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ig_post (ig_post_id),
    INDEX idx_ig_user (ig_username),
    INDEX idx_ig_mitra (mitra_name),
    INDEX idx_ig_taken (taken_at),
    INDEX idx_ig_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabel riwayat IG scrape
CREATE TABLE IF NOT EXISTS ig_scrapes (
    id INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    handle VARCHAR(128) NOT NULL,
    mitra_name VARCHAR(128) NOT NULL DEFAULT '',
    ig_user_id VARCHAR(64) NOT NULL DEFAULT '',
    ig_username VARCHAR(128) NOT NULL DEFAULT '',
    total_posts INT(10) UNSIGNED NOT NULL DEFAULT 0,
    total_likes INT(10) UNSIGNED NOT NULL DEFAULT 0,
    total_plays INT(10) UNSIGNED NOT NULL DEFAULT 0,
    credits_used INT(10) UNSIGNED NOT NULL DEFAULT 0,
    status ENUM('success','error') NOT NULL DEFAULT 'success',
    error_message TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_igs_user (user_id),
    INDEX idx_igs_handle (handle),
    INDEX idx_igs_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migration data instagram_url → instagram_handle dilakukan via PHP script
-- Lihat: database/migrate_ig_handles.php
