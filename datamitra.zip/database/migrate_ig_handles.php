<?php
/**
 * migrate_ig_handles.php — Extract instagram handle from URL and populate instagram_handle column.
 * Run once after running 20260919_instagram_support.sql
 */
require_once __DIR__ . '/../config.php';

$pdo = db();

// Ambil semua mitra yang punya instagram_url
$stmt = $pdo->query("SELECT id, instagram_url FROM mitra WHERE instagram_url != ''");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$updated = 0;
foreach ($rows as $row) {
    $url = $row['instagram_url'];
    if (preg_match('#instagram\.com/([A-Za-z0-9_.]+)#i', $url, $m)) {
        $handle = strtolower($m[1]);
        $pdo->prepare('UPDATE mitra SET instagram_handle = ? WHERE id = ?')->execute([$handle, $row['id']]);
        $updated++;
        echo "ID {$row['id']}: {$url} → @{$handle}\n";
    }
}

echo "\nDone. {$updated} handles migrated.\n";
