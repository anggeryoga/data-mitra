-- ============================================================
-- TikTok Analytics — Schema
-- Tracker konten per akun per bulan (role admin/user)
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS videos;
DROP TABLE IF EXISTS users;

-- ---------- Users ----------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) DEFAULT '',
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Videos (konten hasil input user) ----------
CREATE TABLE videos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    aweme_id VARCHAR(64) NOT NULL,
    url VARCHAR(512) NOT NULL,
    author_unique_id VARCHAR(128) NOT NULL DEFAULT '',
    author_nickname VARCHAR(128) NOT NULL DEFAULT '',
    mitra_name VARCHAR(128) NOT NULL DEFAULT '',
    title TEXT NULL,
    cover_url VARCHAR(512) DEFAULT '',
    create_time INT UNSIGNED NOT NULL,
    play_count INT UNSIGNED NOT NULL DEFAULT 0,
    digg_count INT UNSIGNED NOT NULL DEFAULT 0,
    comment_count INT UNSIGNED NOT NULL DEFAULT 0,
    share_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_videos_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_videos_aweme (aweme_id),
    KEY idx_videos_author (author_unique_id),
    KEY idx_videos_mitra (mitra_name),
    KEY idx_videos_user (user_id),
    KEY idx_videos_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Scrapes (riwayat scrape akun) ----------
CREATE TABLE IF NOT EXISTS scrapes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    handle VARCHAR(128) NOT NULL,
    mitra_name VARCHAR(128) NOT NULL DEFAULT '',
    author_unique_id VARCHAR(128) NOT NULL DEFAULT '',
    author_nickname VARCHAR(128) NOT NULL DEFAULT '',
    total_videos INT UNSIGNED NOT NULL DEFAULT 0,
    total_views INT UNSIGNED NOT NULL DEFAULT 0,
    credits_used INT UNSIGNED NOT NULL DEFAULT 0,
    status ENUM('success','error') NOT NULL DEFAULT 'success',
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_scrapes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    KEY idx_scrapes_handle (handle),
    KEY idx_scrapes_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------- Seed users ----------
-- admin / admin123
INSERT INTO users (username, password_hash, full_name, role) VALUES
('admin', '$2y$10$eFmJ8IKaMaSMyt1kZi2LLOTwqDf1BHDeNx9qjyX2IwWYhNLzgwt0G', 'Administrator', 'admin'),
('user1', '$2y$10$8AuQWo30cuzOls3KZltJne2.MW/HJLOA6AqILRZGt7eOKWSxZnrHy', 'User Satu', 'user'),
('user2', '$2y$10$1jNdqzRtVyhBxnX3XcGtBO6BpB6M119MxpXLy08ZeTwlzpDjyeY2.', 'User Dua', 'user');