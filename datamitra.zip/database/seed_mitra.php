<?php
/**
 * seed_mitra.php — Seed direktori akun TikTok mitra Be Nice Coffee.
 * Jalankan sekali: php seed_mitra.php
 * Aman di-run ulang (pakai INSERT ... ON DUPLICATE KEY UPDATE via UNIQUE key).
 */
declare(strict_types=1);

require __DIR__ . '/../config.php';

// Tambah unique key biar re-run aman
try {
    db()->exec("ALTER TABLE mitra ADD UNIQUE KEY uq_mitra_handle (tiktok_handle)");
} catch (Throwable $e) {
    // sudah ada / kolom dup — ignore
}

$rows = [
    [
        'nama'    => 'Angger Wahyu Ade Saputra',
        'tiktok'  => 'https://www.tiktok.com/@benicecoffeecikarang',
        'ig'      => 'https://www.instagram.com/benicecoffeecikarang/',
        'alamat'  => 'Kontrakan Pak Pram No 4, Jalan Untung Suropati, RT.2/RW.4, Kampung Cibeureum, Cikarang Utara (Kontrakan No 4 Warna Biru), KAB. BEKASI, CIKARANG UTARA, JAWA BARAT, ID, 17831 CIKARANG JAWA BARAT',
    ],
    [
        'nama'    => 'Sri wahyuni',
        'tiktok'  => '',
        'ig'      => '',
        'alamat'  => 'Toto Tentrem Rt 14 Rw 04 Bangunsari Kec. Dolopo Madiun, MADIUN JAWA TIMUR',
    ],
    [
        'nama'    => 'salwa athiyah azzahra',
        'tiktok'  => 'https://www.tiktok.com/@benicetamanraya.tng',
        'ig'      => 'https://www.instagram.com/benicetamanraya.tng',
        'alamat'  => 'Kp Berusaha, Desa Banyu Asih RT.002/001, Kec. Mauk, Kab. Tangerang, No Rumah 40, Tangerang Banten INDONESIA',
    ],
    [
        'nama'    => 'Nor Raniah',
        'tiktok'  => 'https://www.tiktok.com/@be_nice_coffee_sukamara',
        'ig'      => 'https://www.instagram.com/be_nice_coffee_sukamara',
        'alamat'  => 'Jln Pasir Panjang RT 3 No Rumah 153, Desa Sungai Tabuk, Kec. Pantai Lunci, Kab. Sukamara, Kalimantan Tengah, Kode Pos 74775',
    ],
    [
        'nama'    => 'Gustika Wahyu Pratama',
        'tiktok'  => 'https://www.tiktok.com/@gusti.wapra',
        'ig'      => '',
        'alamat'  => 'Dsn. Podang, Kel. Lajo Lor, Kec. Singgahan, Kab. Tuban, TUBAN JAWA TIMUR',
    ],
    [
        'nama'    => 'Agis Setya',
        'tiktok'  => 'https://www.tiktok.com/@benicecoffesukun',
        'ig'      => 'https://www.instagram.com/benicecoffesukun1/',
        'alamat'  => 'Jln Terusan Mergan Lori No 14, Tanjung Rejo, Outlet Be Nice Coffee Sukun, Kota Malang',
    ],
    [
        'nama'    => '',
        'tiktok'  => 'https://www.tiktok.com/@benicecoffee.gokuah_trb',
        'ig'      => 'https://www.instagram.com/benicecoffee_trubus/',
        'alamat'  => 'Jln Trubus, Bangka Tengah, Kec. Lubuk Besar',
    ],
    [
        'nama'    => 'Dedy Tri w',
        'tiktok'  => 'https://www.tiktok.com/@benicecoffee.kajen',
        'ig'      => 'https://www.instagram.com/benicecoffee_kajen/',
        'alamat'  => 'Jln Teuku Umar, Sumurbandung, Gejlig, Kec. Kajen, Kab. Pekalongan, Jawa Tengah (Utara SPBU Kajen)',
    ],
];

$produk = 'Be Nice Coffee';

$ins = db()->prepare('
    INSERT INTO mitra (nama, produk, tiktok_handle, tiktok_url, instagram_url, alamat)
    VALUES (?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
        nama = VALUES(nama),
        produk = VALUES(produk),
        tiktok_url = VALUES(tiktok_url),
        instagram_url = VALUES(instagram_url),
        alamat = VALUES(alamat)
');

$n = 0;
foreach ($rows as $r) {
    $handle = '';
    if ($r['tiktok'] !== '' && preg_match('#tiktok\.com/@([A-Za-z0-9._-]+)#i', $r['tiktok'], $m)) {
        $handle = strtolower($m[1]);
    }
    $ins->execute([$r['nama'], $produk, $handle, $r['tiktok'], $r['ig'], $r['alamat']]);
    $n++;
}

echo "Seed selesai: {$n} mitra dimasukkan.\n";
$total = db()->query('SELECT COUNT(*) FROM mitra')->fetchColumn();
echo "Total baris di tabel mitra: {$total}\n";