-- Migrasi 2026-09-18: tambah kolom `mitra_name` (Nama Mitra) — label partner/brand yang mengelola akun TikTok.
-- Non-destruktif: ALTER TABLE ADD COLUMN, tidak nge-drop data.

SET NAMES utf8mb4;

ALTER TABLE videos
    ADD COLUMN mitra_name VARCHAR(128) NOT NULL DEFAULT '' AFTER author_nickname;

ALTER TABLE scrapes
    ADD COLUMN mitra_name VARCHAR(128) NOT NULL DEFAULT '' AFTER handle;

-- index opsional untuk filter/pencarian mitra
ALTER TABLE videos
    ADD KEY idx_videos_mitra (mitra_name);