-- Migrasi: tambah tabel `scrapes` untuk riwayat scrape akun (ScrapeCreators).
-- Aman dijalankan ulang (CREATE TABLE IF NOT EXISTS) — tidak ngedrop data.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS scrapes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    handle VARCHAR(128) NOT NULL,
    author_unique_id VARCHAR(128) NOT NULL DEFAULT '',
    author_nickname VARCHAR(128) NOT NULL DEFAULT '',
    total_videos INT UNSIGNED NOT NULL DEFAULT 0,
    total_views INT UNSIGNED NOT NULL DEFAULT 0,
    credits_used INT UNSIGNED NOT NULL DEFAULT 0,
    status ENUM('success','error') NOT NULL DEFAULT 'success',
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_scrapes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    KEY idx_scrapes_handle (handle),
    KEY idx_scrapes_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;