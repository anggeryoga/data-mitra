-- Migrasi 2026-09-18: tabel `mitra` — direktori akun TikTok mitra (nama, produk, akun, alamat).
-- Non-destruktif (CREATE TABLE IF NOT EXISTS), tidak menyentuh data lain.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS mitra (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL DEFAULT 0,
    nama VARCHAR(128) NOT NULL DEFAULT '',
    produk VARCHAR(128) NOT NULL DEFAULT '',
    tiktok_handle VARCHAR(128) NOT NULL DEFAULT '',
    tiktok_url VARCHAR(512) NOT NULL DEFAULT '',
    instagram_url VARCHAR(512) NOT NULL DEFAULT '',
    alamat TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_mitra_user (user_id),
    KEY idx_mitra_handle (tiktok_handle),
    KEY idx_mitra_produk (produk)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;