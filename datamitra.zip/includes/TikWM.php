<?php
/**
 * TikWM.php — Wrapper TikWM API untuk TikTok Analytics.
 *
 * TikWM gratis (tanpa API key) hanya bisa narik data per-video dari link video.
 * Endpoint: GET https://www.tikwm.com/api/?url=<video_link>
 *
 * Catatan penting:
 *  - Rate limit gratis: 1 request/detik.
 *  - `/api/user/*` & `/api/?url=<link_profil>` kena Cloudflare / "Url parsing failed".
 *  - URL media signed + expire — jangan cache lama.
 */
declare(strict_types=1);

class TikWM
{
    const BASE = 'https://www.tikwm.com/api/';

    private string $ua;

    public function __construct(?string $ua = null)
    {
        $this->ua = $ua ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' .
            '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
    }

    /**
     * Ambil info + analitik video dari link TikTok.
     * @return array|null data mentah (fields: id, title, create_time,
     *         play_count, digg_count, comment_count, share_count, author{...}, cover)
     */
    public function getVideo(string $url): ?array
    {
        $res = $this->request(self::BASE . '?' . http_build_query(['url' => $url]));
        if ($res === null) {
            return null;
        }
        if (($res['code'] ?? -1) !== 0) {
            // Simpan pesan error agar bisa ditampilkan
            throw new RuntimeException($res['msg'] ?? 'TikWM error: ' . json_encode($res));
        }
        return $res['data'] ?? null;
    }

    private function request(string $url): ?array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_USERAGENT      => $this->ua,
            CURLOPT_REFERER        => 'https://www.tiktok.com/',
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code !== 200) {
            return null;
        }

        $json = json_decode($body, true);
        return is_array($json) ? $json : null;
    }
}