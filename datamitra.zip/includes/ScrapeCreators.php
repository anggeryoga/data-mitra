<?php
/**
 * includes/ScrapeCreators.php — Service wrapper untuk ScrapeCreators API.
 * Endpoint yang dipakai:
 *   - GET /v1/tiktok/profile        -> info profil (followers, total video, dll)
 *   - GET /v3/tiktok/profile/videos -> daftar video (pagination via max_cursor)
 */
declare(strict_types=1);

class ScrapeCreators
{
    private string $apiKey;
    private string $baseUrl;

    public function __construct(?string $apiKey = null, ?string $baseUrl = null)
    {
        $this->apiKey = $apiKey ?? (defined('SC_API_KEY') ? SC_API_KEY : '');
        $this->baseUrl = rtrim($baseUrl ?? (defined('SC_BASE_URL') ? SC_BASE_URL : 'https://api.scrapecreators.com'), '/');
    }

    /**
     * Info profil TikTok.
     * @return array|null {user, stats, statsV2, credits_charged, credits_remaining}
     */
    public function profile(string $handle): ?array
    {
        return $this->get('/v1/tiktok/profile', ['handle' => $handle]);
    }

    /**
     * Daftar video profil TikTok (satu halaman).
     * Response: {aweme_list, max_cursor, has_more, credits_charged, credits_remaining}
     * @param string|null $userId id fungsional TikTok (lebih cepat dari handle saja).
     */
    public function profileVideos(string $handle, $maxCursor = null, ?string $userId = null): ?array
    {
        $params = ['handle' => $handle, 'sort_by' => 'latest', 'trim' => 'true'];
        if ($userId !== null && $userId !== '') {
            $params['user_id'] = $userId;
        }
        if ($maxCursor !== null && $maxCursor !== '') {
            $params['max_cursor'] = (string)$maxCursor;
        }
        return $this->get('/v3/tiktok/profile/videos', $params);
    }

    /**
     * Ambil SEMUA video sebuah akun (pagination penuh).
     * Proteksi max pages diambil dari SC_MAX_PAGES.
     *
     * @param string $handle
     * @param string|null $userId id TikTok (lebih cepat)
     * @param array $opts { stopOnExisting:bool, existingIds:array<string,bool> }
     *        stopOnExisting=true => berhenti lebih awal saat menemukan halaman yang
     *        seluruh videonya sudah tersimpan (re-scrape incremental).
     * @return array {videos, pages, credits, complete, has_more, stopped_early}
     */
    public function fetchAllVideos(string $handle, ?string $userId = null, array $opts = []): array
    {
        $maxPages = defined('SC_MAX_PAGES') ? SC_MAX_PAGES : 25;
        $videos   = [];
        $cursor   = null;
        $pages    = 0;
        $credits  = 0;
        $stoppedEarly = false;

        $stopOnExisting = (bool)($opts['stopOnExisting'] ?? false);
        $existingIds    = (array)($opts['existingIds'] ?? []);

        for ($i = 0; $i < $maxPages; $i++) {
            $res = $this->profileVideos($handle, $cursor, $userId);
            if ($res === null) {
                break;
            }

            $list = $res['aweme_list'] ?? [];
            $credits += (int)($res['credits_charged'] ?? 1);
            $pages++;

            $hasMore = (bool)($res['has_more'] ?? false);
            $cursor  = $res['max_cursor'] ?? null;

            if (count($list) === 0) {
                $hasMore = false;
                break;
            }

            // Re-scrape incremental: kalau seluruh video di halaman ini sudah ada di DB,
            // berarti sudah mencapai video lama yang sudah tersimpan — berhenti.
            if ($stopOnExisting && count($existingIds) > 0) {
                $allKnown = true;
                foreach ($list as $v) {
                    $aid = (string)($v['aweme_id'] ?? '');
                    if ($aid === '' || !isset($existingIds[$aid])) {
                        $allKnown = false;
                        break;
                    }
                }
                if ($allKnown) {
                    $hasMore = false;
                    $stoppedEarly = true;
                }
            }

            foreach ($list as $v) {
                $videos[] = $v;
            }

            if (!$hasMore || $cursor === null || $cursor === '') {
                break;
            }
        }

        return [
            'videos'        => $videos,
            'pages'         => $pages,
            'credits'       => $credits,
            'complete'      => !$hasMore,
            'has_more'      => $hasMore,
            'stopped_early' => $stoppedEarly,
        ];
    }

    /**
     * Ekstrak statistik user dari response profile TikTok.
     * Response: { user:{...}, stats:{ followerCount, followingCount, videoCount, heart } }
     */
    public static function userStats(?array $profile): array
    {
        if ($profile === null) {
            return [
                'followers_count' => 0,
                'following_count' => 0,
                'total_videos'    => 0,
                'heart'           => 0,
            ];
        }

        $stats = $profile['stats'] ?? [];
        $u     = $profile['user'] ?? $profile;

        return [
            'followers_count' => (int)($stats['followerCount'] ?? $u['follower_count'] ?? 0),
            'following_count' => (int)($stats['followingCount'] ?? $u['following_count'] ?? 0),
            'total_videos'    => (int)($stats['videoCount'] ?? $u['aweme_count'] ?? 0),
            'heart'           => (int)($stats['heart'] ?? $stats['heartCount'] ?? 0),
        ];
    }

    // ==========================================================
    // INSTAGRAM METHODS
    // ==========================================================

    /**
     * Info profil Instagram.
     * Response: { data:{ user:{ id, username, full_name, biography, edge_followed_by:{count}, edge_follow:{count}, edge_owner_to_timeline_media:{count} } } }
     * @return array|null
     */
    public function igProfile(string $handle): ?array
    {
        $res = $this->get('/v1/instagram/profile', ['handle' => $handle, 'trim' => 'true']);
        if ($res === null) return null;
        return $res['data'] ?? $res;
    }

    /**
     * Daftar post Instagram (satu halaman).
     * Response: { items:[], next_max_id, credits_charged }
     * Pagination via next_max_id.
     * @return array|null
     */
    public function igPosts(string $handle, ?string $nextMaxId = null): ?array
    {
        $params = ['handle' => $handle, 'trim' => 'true'];
        if ($nextMaxId !== null && $nextMaxId !== '') {
            $params['next_max_id'] = $nextMaxId;
        }
        return $this->get('/v2/instagram/user/posts', $params);
    }

    /**
     * Ambil SEMUA post Instagram (pagination penuh).
     *
     * @param string $handle
     * @param array $opts { stopOnExisting:bool, existingIds:array<string,bool> }
     * @return array {posts, pages, credits, complete, stopped_early}
     */
    public function fetchAllIgPosts(string $handle, array $opts = []): array
    {
        $maxPages = defined('SC_MAX_PAGES') ? SC_MAX_PAGES : 25;
        $posts    = [];
        $cursor   = null;
        $pages    = 0;
        $credits  = 0;
        $stoppedEarly = false;

        $stopOnExisting = (bool)($opts['stopOnExisting'] ?? false);
        $existingIds    = (array)($opts['existingIds'] ?? []);

        for ($i = 0; $i < $maxPages; $i++) {
            $res = $this->igPosts($handle, $cursor);
            if ($res === null) {
                break;
            }

            $list = $res['items'] ?? [];
            $credits += (int)($res['credits_charged'] ?? 1);
            $pages++;

            $nextMaxId = $res['next_max_id'] ?? null;

            if (count($list) === 0) {
                break;
            }

            // Re-scrape incremental
            if ($stopOnExisting && count($existingIds) > 0) {
                $allKnown = true;
                foreach ($list as $p) {
                    $pid = (string)($p['id'] ?? '');
                    if ($pid === '' || !isset($existingIds[$pid])) {
                        $allKnown = false;
                        break;
                    }
                }
                if ($allKnown) {
                    $stoppedEarly = true;
                    break;
                }
            }

            foreach ($list as $p) {
                $posts[] = $p;
            }

            if ($nextMaxId === null || $nextMaxId === '') {
                break;
            }
            $cursor = $nextMaxId;
        }

        return [
            'posts'         => $posts,
            'pages'         => $pages,
            'credits'       => $credits,
            'complete'      => ($nextMaxId === null || $nextMaxId === '') && !$stoppedEarly,
            'stopped_early' => $stoppedEarly,
        ];
    }

    /**
     * Ekstrak statistik user dari response profile Instagram.
     */
    public static function igUserStats(?array $profile): array
    {
        if ($profile === null) {
            return [
                'followers_count' => 0,
                'following_count' => 0,
                'posts_count'     => 0,
            ];
        }

        $user = $profile['user'] ?? $profile;
        return [
            'followers_count' => (int)($user['edge_followed_by']['count'] ?? 0),
            'following_count' => (int)($user['edge_follow']['count'] ?? 0),
            'posts_count'     => (int)($user['edge_owner_to_timeline_media']['count'] ?? 0),
        ];
    }

    // ----------------------------------------------------------

    private function get(string $path, array $params): ?array
    {
        $url = $this->baseUrl . $path . '?' . http_build_query($params);

        $timeout = defined('SC_TIMEOUT') ? SC_TIMEOUT : 60;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_HTTPHEADER     => [
                'x-api-key: ' . $this->apiKey,
                'Accept: application/json',
            ],
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code !== 200) {
            return null;
        }

        $json = json_decode($body, true);
        if (!is_array($json)) {
            return null;
        }

        return $json;
    }
}