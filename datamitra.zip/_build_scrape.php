<?php
/**
 * Generator: build scrape.php (TikTok) - clean, selaras dengan ig-scrape.php
 */
$f = __DIR__ . '/scrape.php';

$php = <<<'PHP'
<?php
require __DIR__ . '/config.php';
require_login();
$pageTitle = 'Scrape TikTok';
$active    = 'scrape';
require_once __DIR__ . '/includes/ScrapeCreators.php';

$uid = (int)(current_user()['id'] ?? 0);
$error = ''; $result = null;
$preHandle = trim($_GET['handle'] ?? '');
$preMitra  = trim($_GET['mitra'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $handle = ltrim(trim($_POST['handle'] ?? ''), '@');
    $mitra  = trim($_POST['mitra_name'] ?? '');
    if ($handle === '') { $error = 'Handle TikTok wajib diisi'; }
    elseif (!preg_match('#^[A-Za-z0-9._-]+$#', $handle)) { $error = 'Format handle tidak valid'; }
    else {
        $sc = new ScrapeCreators();
        $prof = $sc->profile($handle);
        if ($prof === null) { $error = 'Gagal ambil profil. Cek handle & koneksi.'; }
        else {
            $authorUid  = (string)($prof['user']['uniqueId'] ?? $prof['user']['unique_id'] ?? $handle);
            $authorNick = (string)($prof['user']['nickname'] ?? $handle);
            $profTotal  = (int)($prof['stats']['videoCount'] ?? $prof['statsV2']['videoCount'] ?? 0);
            $userId     = (string)($prof['user']['id'] ?? '');
            $existingIds = [];
            $stmt = db()->prepare('SELECT aweme_id FROM videos WHERE author_unique_id = ? AND user_id = ?');
            $stmt->execute([$authorUid, $uid]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $aid) { $existingIds[$aid] = true; }
            $fetched = $sc->fetchAllVideos($handle, ($userId !== '' ? $userId : null), [
                'stopOnExisting' => count($existingIds) > 0,
                'existingIds' => $existingIds,
            ]);
            $videos = $fetched['videos'];
            if (count($videos) === 0) { $error = 'Tidak ada video yang berhasil diambil.'; }
            else {
                $inserted = 0; $updated = 0; $totalViews = 0;
                $ins = db()->prepare('INSERT INTO videos (user_id,aweme_id,url,author_unique_id,author_nickname,mitra_name,title,cover_url,create_time,play_count,digg_count,comment_count,share_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE url=VALUES(url),author_unique_id=VALUES(author_unique_id),author_nickname=VALUES(author_nickname),mitra_name=VALUES(mitra_name),title=VALUES(title),cover_url=VALUES(cover_url),create_time=VALUES(create_time),play_count=VALUES(play_count),digg_count=VALUES(digg_count),comment_count=VALUES(comment_count),share_count=VALUES(share_count)');
                foreach ($videos as $v) {
                    $awemeId = (string)($v['aweme_id'] ?? ''); if ($awemeId === '') continue;
                    $url = (string)($v['url'] ?? $v['share_url'] ?? '');
                    $aUid = (string)($v['author']['unique_id'] ?? $v['author']['uniqueId'] ?? $authorUid);
                    $aNick = (string)($v['author']['nickname'] ?? $authorNick);
                    $desc = (string)($v['desc'] ?? '');
                    $cTime = (int)($v['create_time'] ?? 0);
                    $stat = $v['statistics'] ?? [];
                    $play = (int)($stat['play_count'] ?? 0); $digg = (int)($stat['digg_count'] ?? 0);
                    $comment = (int)($stat['comment_count'] ?? 0); $share = (int)($stat['share_count'] ?? 0);
                    $totalViews += $play;
                    $ins->execute([$uid,$awemeId,$url,$aUid,$aNick,$mitra,$desc,'',$cTime,$play,$digg,$comment,$share]);
                    $rc = $ins->rowCount(); if ($rc===1) $inserted++; elseif ($rc===2) $updated++;
                }
                db()->prepare('INSERT INTO scrapes (user_id,handle,mitra_name,author_unique_id,author_nickname,total_videos,total_views,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?)')->execute([$uid,$handle,$mitra,$authorUid,$authorNick,count($videos),$totalViews,(int)$fetched['credits'],'success',null]);
                $result = ['handle'=>$handle,'mitra'=>$mitra,'nickname'=>$authorNick,'author_uid'=>$authorUid,'profile_total'=>$profTotal,'fetched'=>count($videos),'inserted'=>$inserted,'updated'=>$updated,'total_views'=>$totalViews,'pages'=>(int)$fetched['pages'],'credits'=>(int)$fetched['credits'],'complete'=>(bool)$fetched['complete'],'stopped_early'=>(bool)($fetched['stopped_early']??false)];
            }
        }
    }
}

$scopeWhere = ''; $scopeParams = [];
if (!is_admin()) { $scopeWhere = ' AND s.user_id = ?'; $scopeParams[] = $uid; }
$stmt = db()->prepare("SELECT s.*, u.username FROM scrapes s JOIN users u ON u.id = s.user_id WHERE 1=1 $scopeWhere ORDER BY s.created_at DESC LIMIT 20");
$stmt->execute($scopeParams);
$history = $stmt->fetchAll();

$mitraRows = db()->query("SELECT id, nama, produk, COALESCE(tiktok_handle,'') AS tt_handle FROM mitra WHERE nama != '' ORDER BY produk, nama")->fetchAll(PDO::FETCH_ASSOC);
$brandGroups = [];
$ttAccounts = [];
foreach ($mitraRows as $m) {
    $brand = $m['produk'] !== '' ? $m['produk'] : 'Tanpa Brand';
    $brandGroups[$brand][] = $m;
    if ($m['tt_handle'] !== '') { $ttAccounts[] = $m; }
}

require __DIR__ . '/layouts/header.php';
PHP;

file_put_contents($f, $php);
echo "PHP: " . strlen($php) . " bytes\n";
