<?php
require __DIR__ . '/../config.php';
require_login();
require_once __DIR__ . '/../includes/ScrapeCreators.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

require_csrf();

$uid = (int)(current_user()['id'] ?? 0);
$handle = ltrim(trim($_POST['handle'] ?? ''), '@');
$mitra  = trim($_POST['mitra_name'] ?? '');

if ($handle === '' || !preg_match('#^[A-Za-z0-9_.]+$#', $handle)) {
    echo json_encode(['error' => 'Handle tidak valid']);
    exit;
}

$sc = new ScrapeCreators();
$prof = $sc->igProfile($handle);

if ($prof === null) {
    echo json_encode(['error' => 'Gagal ambil profil Instagram']);
    exit;
}

$stats = ScrapeCreators::igUserStats($prof);
$user = $prof['user'] ?? $prof;
$igUserId = (string)($user['id'] ?? '');
$igUser = (string)($user['username'] ?? $handle);
$fullName = (string)($user['full_name'] ?? $handle);

$existingIds = [];
$s = db()->prepare('SELECT ig_post_id FROM ig_posts WHERE ig_username = ? AND user_id = ?');
$s->execute([$igUser, $uid]);
foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $pid) { $existingIds[$pid] = true; }

$fetched = $sc->fetchAllIgPosts($handle, [
    'stopOnExisting' => count($existingIds) > 0,
    'existingIds' => $existingIds
]);
$posts = $fetched['posts'];

$inserted = 0; $updated = 0; $totalLikes = 0; $totalPlays = 0;
$ins = db()->prepare('INSERT INTO ig_posts (user_id,ig_post_id,shortcode,url,ig_user_id,ig_username,mitra_name,media_type,caption,cover_url,taken_at,like_count,comment_count,play_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE shortcode=VALUES(shortcode),url=VALUES(url),mitra_name=VALUES(mitra_name),caption=VALUES(caption),cover_url=VALUES(cover_url),like_count=VALUES(like_count),comment_count=VALUES(comment_count),play_count=VALUES(play_count)');

foreach ($posts as $p) {
    $postId = (string)($p['id'] ?? ''); if ($postId === '') continue;
    $shortcode = (string)($p['code'] ?? '');
    $mediaType = (int)($p['media_type'] ?? 1);
    $caption = (string)($p['caption']['text'] ?? '');
    $takenAt = (int)($p['taken_at'] ?? 0);
    $likeCount = (int)($p['like_count'] ?? 0);
    $commentCnt = (int)($p['comment_count'] ?? 0);
    $playCount = (int)($p['play_count'] ?? 0);
    $coverUrl = (string)($p['display_uri'] ?? '');
    $url = $shortcode ? 'https://www.instagram.com/p/'.$shortcode : '';
    $totalLikes += $likeCount; $totalPlays += $playCount;
    $ins->execute([$uid,$postId,$shortcode,$url,$igUserId,$igUser,$mitra,$mediaType,$caption,$coverUrl,$takenAt,$likeCount,$commentCnt,$playCount]);
    $rc = $ins->rowCount(); if ($rc===1) $inserted++; elseif ($rc===2) $updated++;
}

db()->prepare('INSERT INTO ig_scrapes (user_id,handle,mitra_name,ig_user_id,ig_username,total_posts,total_likes,total_plays,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?,?)')->execute([$uid,$handle,$mitra,$igUserId,$igUser,count($posts),$totalLikes,$totalPlays,(int)$fetched['credits'],'success',null]);

echo json_encode([
    'success' => true,
    'handle' => $handle,
    'mitra' => $mitra,
    'full_name' => $fullName,
    'ig_user' => $igUser,
    'followers' => $stats['followers_count'],
    'posts_count' => count($posts),
    'inserted' => $inserted,
    'updated' => $updated,
    'total_likes' => $totalLikes,
    'total_plays' => $totalPlays,
    'credits' => (int)$fetched['credits'],
    'complete' => (bool)$fetched['complete']
]);
