<?php
/**
 * api/tiktok-batch-scrape.php - Scrape 1 akun TikTok (dipanggil loop dari batch)
 */
require __DIR__ . '/../config.php';
require_login();
require_once __DIR__ . '/../includes/ScrapeCreators.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}
require_csrf();

$uid = (int)(current_user()['id'] ?? 0);
$handle = ltrim(trim($_POST['handle'] ?? ''), '@');
$mitra  = trim($_POST['mitra_name'] ?? '');

if ($handle === '' || !preg_match('#^[A-Za-z0-9._-]+$#', $handle)) {
    echo json_encode(['success' => false, 'error' => 'Handle tidak valid']);
    exit;
}

$sc = new ScrapeCreators();
$prof = $sc->profile($handle);
if ($prof === null) {
    echo json_encode(['success' => false, 'error' => 'Gagal ambil profil']);
    exit;
}

$authorUid = (string)($prof['user']['uniqueId'] ?? $prof['user']['unique_id'] ?? $handle);
$authorNick = (string)($prof['user']['nickname'] ?? $handle);
$userId = (string)($prof['user']['id'] ?? '');

$existingIds = [];
$stmt = db()->prepare('SELECT aweme_id FROM videos WHERE author_unique_id = ? AND user_id = ?');
$stmt->execute([$authorUid, $uid]);
foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $aid) { $existingIds[$aid] = true; }

$fetched = $sc->fetchAllVideos($handle, ($userId !== '' ? $userId : null), [
    'stopOnExisting' => count($existingIds) > 0,
    'existingIds' => $existingIds,
]);
$videos = $fetched['videos'];

$inserted = 0; $updated = 0; $totalViews = 0;
$ins = db()->prepare('INSERT INTO videos (user_id,aweme_id,url,author_unique_id,author_nickname,mitra_name,title,cover_url,create_time,play_count,digg_count,comment_count,share_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE url=VALUES(url),author_unique_id=VALUES(author_unique_id),author_nickname=VALUES(author_nickname),mitra_name=VALUES(mitra_name),title=VALUES(title),cover_url=VALUES(cover_url),create_time=VALUES(create_time),play_count=VALUES(play_count),digg_count=VALUES(digg_count),comment_count=VALUES(comment_count),share_count=VALUES(share_count)');

foreach ($videos as $v) {
    $awemeId = (string)($v['aweme_id'] ?? '');
    if ($awemeId === '') continue;
    $url = (string)($v['url'] ?? $v['share_url'] ?? '');
    $aUid = (string)($v['author']['unique_id'] ?? $v['author']['uniqueId'] ?? $authorUid);
    $aNick = (string)($v['author']['nickname'] ?? $authorNick);
    $desc = (string)($v['desc'] ?? '');
    $createTime = (int)($v['create_time'] ?? 0);
    $stat = $v['statistics'] ?? [];
    $play = (int)($stat['play_count'] ?? 0);
    $digg = (int)($stat['digg_count'] ?? 0);
    $comment = (int)($stat['comment_count'] ?? 0);
    $share = (int)($stat['share_count'] ?? 0);
    $totalViews += $play;
    $ins->execute([$uid,$awemeId,$url,$aUid,$aNick,$mitra,$desc,'',$createTime,$play,$digg,$comment,$share]);
    $rc = $ins->rowCount();
    if ($rc === 1) $inserted++;
    elseif ($rc === 2) $updated++;
}

db()->prepare('INSERT INTO scrapes (user_id,handle,mitra_name,author_unique_id,author_nickname,total_videos,total_views,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?)')
    ->execute([$uid,$handle,$mitra,$authorUid,$authorNick,count($videos),$totalViews,(int)$fetched['credits'],'success',null]);

echo json_encode([
    'success' => true,
    'handle' => $handle,
    'mitra' => $mitra,
    'nickname' => $authorNick,
    'total_videos' => count($videos),
    'inserted' => $inserted,
    'updated' => $updated,
    'total_views' => $totalViews,
    'credits' => (int)$fetched['credits'],
]);
