<?php
/**
 * config.php — Konfigurasi TikTok Analytics (tracker konten per akun per bulan)
 */
declare(strict_types=1);

// ----- Database -----
const DB_HOST = 'localhost';
const DB_PORT = 3306;
const DB_NAME = 'paketkemi_datamitra';
const DB_USER = 'paketkemi_datamitra';
const DB_PASS = 'VV!*yzgZ+*yT!4cC';

// ----- ScrapeCreators API -----
const SC_API_KEY   = 'jKEy084fHaTWsHkY1xjF7wVgIT83';
const SC_BASE_URL  = 'https://api.scrapecreators.com';
const SC_TIMEOUT   = 60;
const SC_MAX_PAGES = 25; // batas pagination per scrape (proteksi credit)

// ----- Aplikasi -----
const APP_NAME = 'TikTok Analytics';
const SESSION_NAME = 'tiktok_analytics_session';

// ----- Init koneksi PDO -----
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('Koneksi database gagal: ' . $e->getMessage());
        }
    }
    return $pdo;
}

// ----- Session -----
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// ----- Helper -----
function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function get_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function current_user(): array
{
    return $_SESSION['user'] ?? [];
}

function is_admin(): bool
{
    return (current_user()['role'] ?? '') === 'admin';
}

// ----- CSRF -----
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_check(?string $token): bool
{
    return is_string($token) && hash_equals($_SESSION['csrf'] ?? '', $token);
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function require_csrf(): void
{
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
    if (!csrf_check($token)) {
        http_response_code(403);
        exit('CSRF token tidak valid');
    }
}

function format_number(int|float $n): string
{
    return number_format($n, 0, ',', '.');
}

function format_compact(int $n): string
{
    if ($n >= 1_000_000) return round($n / 1_000_000, 1) . 'M';
    if ($n >= 1_000) return round($n / 1_000, 1) . 'K';
    return (string)$n;
}

/**
 * Daftar mitra (nama + produk) dari tabel mitra.
 * Return array asosiatif: nama => produk (untuk label dropdown).
 */
function mitra_names(): array
{
    $pdo = db();
    $stmt = $pdo->query("SELECT nama, produk FROM mitra WHERE nama != '' ORDER BY produk, nama");
    $result = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $result[$r['nama']] = $r['produk'];
    }
    return $result;
}

/**
 * Render <datalist> untuk input Nama Mitra.
 */
function mitra_datalist(string $id = 'mitra-list'): string
{
    $html = '<datalist id="' . e($id) . '">';
    foreach (mitra_names() as $nama => $produk) {
        $html .= '<option value="' . e($nama) . '">' . e($produk) . '</option>';
    }
    $html .= '</datalist>';
    return $html;
}

/**
 * Daftar akun TikTok unik (dari videos + scrapes), scoped sesuai role.
 */
function scraped_accounts(): array
{
    $pdo = db();
    $sql = "SELECT DISTINCT author_unique_id, MAX(author_nickname) AS nick, MAX(mitra_name) AS mitra
            FROM videos WHERE author_unique_id <> ''";
    $params = [];
    if (!is_admin()) {
        $sql .= ' AND user_id = ?';
        $params[] = (int)(current_user()['id'] ?? 0);
    }
    $sql .= ' GROUP BY author_unique_id ORDER BY author_unique_id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/**
 * Render <select> dropdown for existing scraped accounts.
 */
function akun_select(array $accounts): string
{
    $html = '<select id="akun-select" class="form-control" style="margin-bottom:.5rem">';
    $html .= '<option value="">-- Pilih akun yang sudah ada, atau ketik manual di bawah --</option>';
    foreach ($accounts as $a) {
        $label = '@' . $a['author_unique_id'];
        if ($a['mitra'] !== '') {
            $label .= ' — ' . $a['mitra'];
        }
        $html .= '<option value="' . e($a['author_unique_id']) . '" data-mitra="' . e($a['mitra']) . '">' . e($label) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

/**
 * Render <select> dropdown for mitra names (nama + produk sebagai label).
 */
function mitra_select(array $names, string $id = 'mitra-select'): string
{
    $html = '<select id="' . e($id) . '" class="form-control" style="margin-bottom:.5rem">';
    $html .= '<option value="">-- Pilih mitra, atau ketik manual --</option>';
    foreach ($names as $nama => $produk) {
        $label = $nama . ($produk !== '' ? ' (' . $produk . ')' : '');
        $html .= '<option value="' . e($nama) . '">' . e($label) . '</option>';
    }
    $html .= '</select>';
    return $html;
}