<?php
require __DIR__ . '/config.php';
require_login();
$pageTitle = 'Scrape Instagram';
$active    = 'ig-scrape';
require_once __DIR__ . '/includes/ScrapeCreators.php';

$uid = (int)(current_user()['id'] ?? 0);
$error = ''; $result = null;
$preHandle = trim($_GET['handle'] ?? '');
$preMitra  = trim($_GET['mitra'] ?? '');

// ==========================================
// 1. BACKEND LOGIC (SUDAH FIX SEMUA BUG)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $handle = ltrim(trim($_POST['handle'] ?? ''), '@');
    $mitra  = trim($_POST['mitra_name'] ?? '');
    
    if ($handle === '') { 
        $error = 'Handle Instagram wajib diisi'; 
    } elseif (!preg_match('#^[A-Za-z0-9_.]+$#', $handle)) { 
        $error = 'Format handle tidak valid'; 
    } else {
        $sc = new ScrapeCreators();
        $prof = $sc->igProfile($handle);
        
        if ($prof === null) { 
            $error = 'Gagal ambil profil. Pastikan username benar dan akun tidak di-private.'; 
        } else {
            $stats = ScrapeCreators::igUserStats($prof);
            $user = $prof['user'] ?? $prof;
            $igUserId = (string)($user['id'] ?? '');
            $igUser = (string)($user['username'] ?? $handle);
            $fullName = (string)($user['full_name'] ?? $handle);
            
            // FIX: Cek database berdasarkan ID User Angka (ig_user_id), bukan username
            $existingIds = [];
            $stmt = db()->prepare('SELECT ig_post_id FROM ig_posts WHERE ig_user_id = ? AND user_id = ?');
            $stmt->execute([$igUserId, $uid]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $pid) { 
                $existingIds[$pid] = true; 
            }
            
            $fetched = $sc->fetchAllIgPosts($handle, [
                'stopOnExisting' => count($existingIds) > 0,
                'existingIds' => $existingIds,
            ]);
            
            // FIX: Mencegah error jika API gagal mengembalikan key 'posts'
            $posts = $fetched['posts'] ?? [];
            
            if (count($posts) === 0 && !($fetched['stopped_early'] ?? false)) { 
                $error = 'Tidak ada post baru yang berhasil diambil.'; 
            } else {
                $inserted = 0; $updated = 0; $totalLikes = 0; $totalPlays = 0;
                
                // FIX: Tambahkan semua field yang bisa berubah ke ON DUPLICATE KEY UPDATE
                $ins = db()->prepare('INSERT INTO ig_posts (user_id,ig_post_id,shortcode,url,ig_user_id,ig_username,mitra_name,media_type,caption,cover_url,taken_at,like_count,comment_count,play_count) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) 
                ON DUPLICATE KEY UPDATE 
                shortcode=VALUES(shortcode), url=VALUES(url), ig_username=VALUES(ig_username), mitra_name=VALUES(mitra_name), caption=VALUES(caption), cover_url=VALUES(cover_url), like_count=VALUES(like_count), comment_count=VALUES(comment_count), play_count=VALUES(play_count), media_type=VALUES(media_type)');
                
                foreach ($posts as $p) {
                    $postId = (string)($p['id'] ?? ''); 
                    if ($postId === '') continue;
                    
                    $shortcode = (string)($p['code'] ?? '');
                    $mediaType = (int)($p['media_type'] ?? 1);
                    
                    // FIX: Penanganan aman untuk Caption (Bisa Array, Bisa String, Bisa Null)
                    $rawCaption = $p['caption'] ?? '';
                    $caption = is_array($rawCaption) ? (string)($rawCaption['text'] ?? '') : (string)$rawCaption;
                    
                    $takenAt = (int)($p['taken_at'] ?? 0);
                    $likeCount = (int)($p['like_count'] ?? 0);
                    $commentCnt = (int)($p['comment_count'] ?? 0);
                    $playCount = (int)($p['play_count'] ?? 0);
                    $coverUrl = (string)($p['display_uri'] ?? '');
                    $url = $shortcode ? 'https://www.instagram.com/p/'.$shortcode : '';
                    
                    $totalLikes += $likeCount; 
                    $totalPlays += $playCount;
                    
                    $ins->execute([$uid, $postId, $shortcode, $url, $igUserId, $igUser, $mitra, $mediaType, $caption, $coverUrl, $takenAt, $likeCount, $commentCnt, $playCount]);
                    
                    $rc = $ins->rowCount(); 
                    if ($rc === 1) $inserted++; elseif ($rc === 2) $updated++;
                }
                
                $creditsUsed = (int)($fetched['credits'] ?? 0);
                
                // Simpan ke history
                db()->prepare('INSERT INTO ig_scrapes (user_id,handle,mitra_name,ig_user_id,ig_username,total_posts,total_likes,total_plays,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
                  ->execute([$uid, $handle, $mitra, $igUserId, $igUser, count($posts), $totalLikes, $totalPlays, $creditsUsed, 'success', null]);
                
                $result = [
                    'handle' => $handle, 'mitra' => $mitra, 'full_name' => $fullName, 'ig_user' => $igUser,
                    'profile_total' => $stats['posts_count'] ?? 0, 'fetched' => count($posts),
                    'inserted' => $inserted, 'updated' => $updated, 'total_likes' => $totalLikes, 'total_plays' => $totalPlays,
                    'pages' => (int)($fetched['pages'] ?? 1), 'credits' => $creditsUsed,
                    'complete' => (bool)($fetched['complete'] ?? true), 'stopped_early' => (bool)($fetched['stopped_early'] ?? false)
                ];
            }
        }
    }
}

// ==========================================
// 2. DATA UNTUK TAMPILAN (UI)
// ==========================================
$scopeWhere = ''; $scopeParams = [];
if (!is_admin()) { $scopeWhere = ' AND s.user_id = ?'; $scopeParams[] = $uid; }
$stmt = db()->prepare("SELECT s.*, u.username FROM ig_scrapes s JOIN users u ON u.id = s.user_id WHERE 1=1 $scopeWhere ORDER BY s.created_at DESC LIMIT 20");
$stmt->execute($scopeParams);
$history = $stmt->fetchAll();

$mitraRows = db()->query("SELECT id, nama, produk, COALESCE(instagram_handle,'') AS ig_handle FROM mitra WHERE nama != '' ORDER BY produk, nama")->fetchAll(PDO::FETCH_ASSOC);
$brandGroups = []; $igAccounts = [];
foreach ($mitraRows as $m) {
    $brand = $m['produk'] !== '' ? $m['produk'] : 'Tanpa Brand';
    $brandGroups[$brand][] = $m;
    if ($m['ig_handle'] !== '') { $igAccounts[] = $m; }
}

require __DIR__ . '/layouts/header.php';
?>

<!-- ========================================== -->
<!-- 3. FRONTEND UI (HTML & CSS) -->
<!-- ========================================== -->
<style>
:root{
    --tt-dark:#0f172a; 
    --ig-grad:linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
    --ig-solid:#dc2743;
}
.platform-card{display:flex;gap:1rem;margin-bottom:1.5rem}
.platform-btn{flex:1;padding:1.2rem;border-radius:12px;text-align:center;text-decoration:none!important;border:2px solid transparent;transition:transform .12s,box-shadow .12s; background:#fff; color:#333;}
.platform-btn:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(0,0,0,.1)}
.platform-btn.active-platform{box-shadow:0 2px 12px rgba(0,0,0,.12);border-color:rgba(255,255,255,.3); color:#fff !important;}
.platform-btn .p-icon{font-size:1.5rem;margin-bottom:.3rem}
.platform-btn .p-title{font-weight:700;font-size:1.05rem}
.platform-btn .p-desc{font-size:.78rem;opacity:.8;margin-top:.2rem}
.flow-steps{display:flex;gap:.5rem;margin-bottom:1.5rem}
.flow-item{flex:1;display:flex;align-items:center;gap:.6rem;padding:.8rem 1rem;background:#fff;border:1px solid #e2e8f0;border-radius:10px}
.flow-item.active{border-color:var(--ig-solid);background:rgba(220, 39, 67, 0.04)}
.flow-num{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;background:#f1f5f9;color:#64748b;flex-shrink:0}
.flow-item.active .flow-num{background:var(--ig-grad);color:#fff}
.flow-text{font-size:.85rem;font-weight:500;color:#475569}
.form-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem}
.form-card h3{font-size:1.05rem;font-weight:700;margin:0 0 .3rem;color:#1e293b;display:flex;align-items:center;gap:.4rem}
.form-card .form-desc{font-size:.85rem;color:#64748b;margin:0 0 1.2rem}
.pk-select-wrap{position:relative}
.pk-select-wrap select{width:100%;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit;background:#fff;appearance:none;-webkit-appearance:none;cursor:pointer}
.pk-select-wrap select:focus{outline:none;border-color:var(--ig-solid);box-shadow:0 0 0 3px rgba(220, 39, 67, 0.12)}
.pk-select-wrap::after{content:"\25BC";position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#94a3b8;pointer-events:none;font-size:.7rem}
.pk-handle-row{display:flex;align-items:center;gap:.5rem}
.pk-handle-prefix{font-size:1.1rem;color:#94a3b8;font-weight:600;flex-shrink:0}
.pk-handle-input{flex:1;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit}
.pk-handle-input:focus{outline:none;border-color:var(--ig-solid);box-shadow:0 0 0 3px rgba(220, 39, 67, 0.12)}
.pk-btn{background:var(--ig-grad);border:none;color:#fff;padding:.7rem 1.5rem;font-weight:700;border-radius:10px;cursor:pointer;font-family:inherit;font-size:.9rem;display:inline-flex;align-items:center;gap:.4rem}
.pk-btn:hover{opacity:.9;transform:translateY(-1px)}
.pk-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.ig-result-box{border-color:rgba(220, 39, 67, 0.25);background:rgba(220, 39, 67, 0.04); padding: 15px; border-radius:10px;}
.ig-result-box .result-title{color:var(--ig-solid); margin-top:0;}
.history-table{width:100%;border-collapse:collapse;font-size:.85rem}
.history-table th{text-align:left;padding:.6rem .8rem;border-bottom:2px solid #e2e8f0;color:#64748b;font-weight:600;font-size:.78rem;text-transform:uppercase;letter-spacing:.03em}
.history-table th.ta-right{text-align:right}
.history-table td{padding:.6rem .8rem;border-bottom:1px solid #f1f5f9}
.history-table td.ta-right{text-align:right}
.history-table .cell-primary{font-weight:600;color:#1e293b}
.history-table .cell-sub{font-size:.78rem;color:#94a3b8;margin-top:2px}
.badge-ig{display:inline-block;padding:2px 8px;border-radius:6px;font-size:.72rem;font-weight:600;background:var(--ig-grad);color:#fff;margin-right:4px}
/* Batch styling */
.batch-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem;margin-top:1.5rem}
.batch-list{max-height:320px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:1rem}
.batch-item{display:flex;align-items:center;gap:.8rem;padding:.65rem 1rem;border-bottom:1px solid #f1f5f9;font-size:.85rem;}
.batch-summary{display:flex;gap:1.5rem;flex-wrap:wrap;padding:.8rem 1rem;background:#f8fafc;border-radius:10px;font-size:.85rem;margin-top:1rem}

/* FIX: Desain Loading Baru (Bukan Popup Fullscreen) */
.inline-loading-box {
    display: none; 
    margin-top: 1.5rem; 
    padding: 1.5rem; 
    background: #f8fafc; 
    border: 1px dashed #cbd5e1; 
    border-radius: 12px; 
    text-align: center;
    animation: fadeIn 0.3s ease-in-out;
}
@keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
@keyframes spin{to{transform:rotate(360deg)}}
.spinner-sm{width:20px;height:20px;border:3px solid rgba(220, 39, 67, 0.2);border-top-color:var(--ig-solid);border-radius:50%;animation:spin .8s linear infinite; display:inline-block;}
</style>

<div class="platform-card">
  <a href="scrape.php" class="platform-btn">
    <div class="p-icon">&#9654;</div>
    <div class="p-title">TikTok</div>
    <div class="p-desc">Scrape semua video dari akun TikTok</div>
  </a>
  <a href="ig-scrape.php" class="platform-btn active-platform" style="background:var(--ig-grad);">
    <div class="p-icon">&#9679;</div>
    <div class="p-title">Instagram</div>
    <div class="p-desc">Scrape semua post dari akun Instagram</div>
  </a>
</div>

<div class="flow-steps">
  <div class="flow-item active"><div class="flow-num">1</div><div class="flow-text">Pilih Mitra</div></div>
  <div class="flow-item"><div class="flow-num">2</div><div class="flow-text">Cek Username IG</div></div>
  <div class="flow-item"><div class="flow-num">3</div><div class="flow-text">Scrape &amp; Simpan</div></div>
</div>

<div class="grid-2">
<div class="form-card">
  <h3><span class="badge-ig">IG</span> Scrape Instagram</h3>
  <p class="form-desc">Pilih mitra, username IG auto-fill. Scrape Post/Reels/Video.</p>
  
  <?php if ($error): ?><div class="alert alert-danger" style="color:red; margin-bottom:15px;"><strong>Error:</strong> <?= e($error) ?></div><?php endif; ?>
  
  <form method="post" action="ig-scrape.php" id="ig-form">
    <?= csrf_field() ?>
    <div class="form-group" style="margin-bottom:15px;">
      <label for="mitra-select" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem; display:block;">Pilih Mitra</label>
      <div class="pk-select-wrap">
        <select id="mitra-select" name="mitra_name" required>
          <option value="">-- Pilih mitra --</option>
          <?php foreach ($brandGroups as $brand => $mitras): ?>
            <optgroup label="<?= e($brand) ?>">
            <?php foreach ($mitras as $m):
              $ig = $m['ig_handle'] !== '' ? '@'.$m['ig_handle'] : '(belum ada IG)';
            ?>
              <option value="<?= e($m['nama']) ?>" data-ig="<?= e($m['ig_handle']) ?>" <?= ($preMitra === $m['nama']) ? 'selected' : '' ?>>
                <?= e($m['nama']) ?> &mdash; <?= e($ig) ?>
              </option>
            <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    
    <div class="form-group" style="margin-bottom:20px;">
      <label for="handle" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem; display:block;">Username Instagram</label>
      <div class="pk-handle-row">
        <span class="pk-handle-prefix">@</span>
        <input type="text" id="handle" name="handle" class="pk-handle-input" required placeholder="username_ig" value="<?= e($_POST['handle'] ?? $preHandle) ?>">
      </div>
    </div>
    
    <button type="submit" class="pk-btn" id="btn-scrape">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
      Scrape Instagram
    </button>
  </form>

  <!-- FIX: Loading UI Inline (Tidak Fullscreen) -->
  <div class="inline-loading-box" id="inline-loading">
    <div class="spinner-sm" style="margin-bottom:10px;"></div>
    <div style="font-weight:bold; color:var(--ig-solid); font-size:1rem;">Menghubungi Instagram...</div>
    <div style="font-size:0.85rem; color:#64748b; margin-top:5px;">Sedang mengambil data postingan. Mohon tunggu.</div>
    <div style="font-size:0.8rem; font-weight:bold; margin-top:10px; background:#e2e8f0; display:inline-block; padding:4px 10px; border-radius:20px;">Waktu: <span id="loading-timer">0</span> detik</div>
  </div>

  <?php if ($result): ?>
  <div class="ig-result-box" style="margin-top:1.2rem">
    <h3 class="result-title">Berhasil: @<?= e($result['handle']) ?></h3>
    <div class="result-meta" style="font-size:0.9rem; line-height:1.6;">
      <div><span style="color:#64748b;">Mitra:</span> <strong><?= e($result['mitra']) ?></strong></div>
      <div><span style="color:#64748b;">Total Post di Profil:</span> <strong><?= (int)$result['profile_total'] ?></strong></div>
      <div><span style="color:#64748b;">Post Terambil:</span> <strong><?= (int)$result['fetched'] ?></strong></div>
      <div><span style="color:#64748b;">Post Baru Disimpan:</span> <strong style="color:green;"><?= (int)$result['inserted'] ?></strong></div>
      <div><span style="color:#64748b;">Post Diperbarui:</span> <strong><?= (int)$result['updated'] ?></strong></div>
      <div><span style="color:#64748b;">Total Likes Dihitung:</span> <strong><?= number_format((int)$result['total_likes']) ?></strong></div>
    </div>
    <?php if (!$result['complete']): ?><div class="alert alert-warning" style="margin-top:10px; font-size:0.85rem;">Pagination belum tuntas. Scrape ulang untuk lanjut.</div><?php endif; ?>
    <?php if ($result['stopped_early']): ?><div class="alert alert-info" style="margin-top:10px; font-size:0.85rem;">Sistem berhenti otomatis (postingan lama sudah ada di database).</div><?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<div class="card form-card">
  <h2 style="font-size: 1.1rem; margin-top:0;">Riwayat Scrape IG</h2>
  <?php if (count($history) === 0): ?>
    <div class="empty">Belum ada scrape Instagram.</div>
  <?php else: ?>
    <div style="overflow-x:auto;">
      <table class="history-table">
        <thead><tr><th>Akun</th><th class="ta-right">Post</th><th class="ta-right">Likes</th><th>Waktu</th></tr></thead>
        <tbody>
          <?php foreach ($history as $h): ?>
          <tr>
            <td><div class="cell-primary"><span class="badge-ig">IG</span>@<?= e($h['handle']) ?></div><div class="cell-sub"><?= e($h['mitra_name']) ?></div></td>
            <td class="ta-right"><strong><?= (int)$h['total_posts'] ?></strong></td>
            <td class="ta-right"><?= number_format((int)$h['total_likes']) ?></td>
            <td class="cell-sub"><?= e(date('d M y H:i', strtotime($h['created_at']))) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
</div>

<?php if (count($igAccounts) > 0): ?>
<div class="batch-card">
  <h3><span class="badge-ig">BATCH</span> Scrape Semua Akun Instagram</h3>
  <p style="font-size:.85rem;color:#64748b;margin:0 0 1rem">Otomatis scrape <?= count($igAccounts) ?> akun IG mitra satu per satu.</p>
  <button type="button" class="pk-btn" id="btn-batch" onclick="startBatch()">
    Mulai Batch Scrape (<?= count($igAccounts) ?> akun)
  </button>
  
  <div class="batch-list" id="batch-list" style="display:none;margin-top:1rem">
    <?php $idx = 0; foreach ($igAccounts as $acc): $idx++; ?>
    <div class="batch-item" id="batch-item-<?= $idx ?>" data-handle="<?= e($acc['ig_handle']) ?>" data-name="<?= e($acc['nama']) ?>">
      <div class="batch-name" style="flex:1;"><strong><?= e($acc['nama']) ?></strong> <br><small>@<?= e($acc['ig_handle']) ?></small></div>
      <div class="batch-status" id="batch-status-<?= $idx ?>" style="width:30px; text-align:center;">-</div>
    </div>
    <?php endforeach; ?>
  </div>
  
  <div class="batch-summary" id="batch-summary" style="display:none">
    <div class="stat"><span style="color:#64748b;">Selesai:</span> <strong id="batch-done">0</strong></div>
    <div class="stat"><span style="color:#64748b;">Gagal:</span> <strong id="batch-fail">0</strong></div>
    <div class="stat"><span style="color:#64748b;">Total Posts:</span> <strong id="batch-videos">0</strong></div>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/layouts/footer.php'; ?>

<!-- ========================================== -->
<!-- 4. JAVASCRIPT LOGIC -->
<!-- ========================================== -->
<script>
(function(){
  // 1. Auto-fill Form saat memilih Mitra
  var sel = document.getElementById('mitra-select');
  var handleInput = document.getElementById('handle');
  if (sel && handleInput) {
    sel.addEventListener('change', function() {
      var opt = sel.options[sel.selectedIndex];
      var ig = opt ? opt.getAttribute('data-ig') : '';
      if (ig && ig !== '') { handleInput.value = ig; }
    });
  }

  // 2. Tampilkan Loading Box di dalam Card saat form disubmit
  var form = document.getElementById('ig-form');
  var inlineLoading = document.getElementById('inline-loading');
  var timerEl = document.getElementById('loading-timer');
  var btn = document.getElementById('btn-scrape');
  
  if (form && inlineLoading) {
    form.addEventListener('submit', function(e) {
      if (!handleInput.value.trim()) { e.preventDefault(); return; }
      
      // Sembunyikan result-box jika sebelumnya ada
      var resultBox = document.querySelector('.ig-result-box');
      if(resultBox) resultBox.style.display = 'none';

      // Munculkan Kotak Loading
      inlineLoading.style.display = 'block';
      
      // Matikan tombol
      btn.disabled = true;
      btn.innerHTML = 'Sedang Memproses...';
      
      // Mulai Timer
      var sec = 0;
      setInterval(function() { sec++; if (timerEl) timerEl.textContent = sec; }, 1000);
    });
  }

  // 3. Logika Batch Scrape (Memanggil file API)
  window.startBatch = function() {
    var items = document.querySelectorAll('#batch-list .batch-item');
    if (!items.length) return;
    
    var btnBatch = document.getElementById('btn-batch');
    var list = document.getElementById('batch-list');
    var summary = document.getElementById('batch-summary');
    
    btnBatch.disabled = true;
    btnBatch.textContent = 'Proses Batch Berjalan...';
    list.style.display = 'block';
    summary.style.display = 'flex';
    
    var csrf = document.querySelector('input[name="csrf_token"]');
    var csrfToken = csrf ? csrf.value : '';
    
    var done=0, fail=0, totalPosts=0, idx=0;
    
    function scrapeNext() {
      if (idx >= items.length) {
        btnBatch.textContent = 'Selesai! ' + done + ' berhasil, ' + fail + ' gagal';
        btnBatch.disabled = false;
        return;
      }
      
      var item = items[idx];
      var handle = item.getAttribute('data-handle');
      var name = item.getAttribute('data-name');
      var statusEl = document.getElementById('batch-status-' + (idx + 1));
      
      item.style.background = 'rgba(220, 39, 67, 0.05)';
      statusEl.innerHTML = '<div class="spinner-sm"></div>';
      
      var fd = new FormData();
      fd.append('csrf_token', csrfToken);
      fd.append('handle', handle);
      fd.append('mitra_name', name);
      
      fetch('api/ig-batch-scrape.php', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(data){
          item.style.background = 'transparent';
          if (data.success) {
            statusEl.innerHTML = '<span style="color:#16a34a;font-weight:700">&#10003;</span>';
            done++; 
            totalPosts += (data.total_posts || 0); 
          } else {
            statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700">&#10007;</span>';
            fail++;
          }
        }).catch(function(){
          item.style.background = 'transparent';
          statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700">&#10007;</span>';
          fail++;
        }).finally(function(){
          document.getElementById('batch-done').textContent = done;
          document.getElementById('batch-fail').textContent = fail;
          document.getElementById('batch-videos').textContent = totalPosts;
          idx++; 
          scrapeNext();
        });
    }
    
    scrapeNext();
  };
})();
</script>