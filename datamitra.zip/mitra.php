<?php
/**
 * mitra.php — Direktori akun TikTok mitra (nama, produk, akun, alamat).
 * Semua role bisa lihat. Admin bisa tambah/edit/hapus dan plotting user.
 */
require __DIR__ . '/config.php';
require_login();

$pageTitle = 'Direktori Mitra';
$active    = 'mitra';

$uid   = (int)(current_user()['id'] ?? 0);
$admin = is_admin();
$error = '';

// [BARU] Ambil daftar semua user untuk dropdown plotting (Hanya untuk Admin)
$userList = [];
if ($admin) {
    $stmtUsers = db()->query("SELECT id, username, role FROM users ORDER BY role ASC, username ASC");
    $userList = $stmtUsers->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();

    if (!$admin) {
        redirect('mitra.php');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        // [BARU] Tangkap user_id dari form dropdown, jika kosong gunakan ID admin saat ini
        $assignUserId = (int)($_POST['assign_user_id'] ?? $uid); 
        
        $nama = trim($_POST['nama'] ?? '');
        $produk = trim($_POST['produk'] ?? '');
        $tiktok = trim($_POST['tiktok'] ?? '');
        $ig = trim($_POST['instagram'] ?? '');
        $igHandle = '';
        
        // Ekstrak IG handle dari URL atau input langsung
        if ($ig !== '') {
            if (preg_match('#instagram\.com/([A-Za-z0-9_.]+)#i', $ig, $m)) {
                $igHandle = strtolower($m[1]);
            } elseif (preg_match('#^@?([A-Za-z0-9_.]+)$#', $ig, $m)) {
                $igHandle = strtolower($m[1]);
                $ig = 'https://www.instagram.com/' . $igHandle;
            }
        }
        $alamat = trim($_POST['alamat'] ?? '');

        // ===== Validasi =====
        $errors = [];

        // Nama
        if ($nama === '') {
            $errors[] = 'Nama mitra wajib diisi.';
        } else {
            if (mb_strlen($nama) < 3) $errors[] = 'Nama mitra minimal 3 karakter.';
            if (mb_strlen($nama) > 128) $errors[] = 'Nama mitra maksimal 128 karakter.';
            if (!preg_match('/^[\p{L}\p{N}\s.,\'\-]+$/u', $nama)) $errors[] = 'Nama mitra mengandung karakter tidak valid.';
        }

        // Produk
        if ($produk === '') {
            $errors[] = 'Produk/brand wajib diisi (contoh: Be Nice Coffee).';
        } else {
            if (mb_strlen($produk) > 128) $errors[] = 'Produk maksimal 128 karakter.';
        }

        // TikTok (opsional kalau ada IG)
        $handle = '';
        if ($tiktok !== '') {
            if (preg_match('#^(?:https?://)?(?:www\.|m\.)?tiktok\.com/@([A-Za-z0-9._-]+)/?#i', $tiktok, $m)) {
                $handle = strtolower($m[1]);
            } elseif (preg_match('#^@?([A-Za-z0-9._-]+)$#', $tiktok, $m)) {
                $handle = strtolower($m[1]);
            }
            if ($handle === '') {
                $errors[] = 'Format TikTok tidak valid. Isi username atau link lengkap.';
            } else {
                if (strlen($handle) < 2 || strlen($handle) > 24) $errors[] = 'Username TikTok harus 2-24 karakter.';
                if (!preg_match('/^[A-Za-z0-9._-]+$/', $handle)) $errors[] = 'Username TikTok hanya boleh huruf, angka, underscore, titik, dan strip.';
            }
        }
        if ($handle === '' && $igHandle === '') {
            $errors[] = 'Minimal isi salah satu: Akun TikTok atau Akun Instagram.';
        }

        // Instagram (opsional)
        if ($ig !== '' && $igHandle === '') {
            $errors[] = 'Format Instagram tidak valid. Isi username (contoh: username) atau link lengkap.';
        }
        if ($igHandle !== '') {
            if (strlen($igHandle) < 1 || strlen($igHandle) > 30) $errors[] = 'Username Instagram harus 1-30 karakter.';
            if (!preg_match('/^[A-Za-z0-9_.]+$/', $igHandle)) $errors[] = 'Username Instagram hanya boleh huruf, angka, underscore, dan titik.';
        }

        // Alamat (opsional)
        if (mb_strlen($alamat) > 500) $errors[] = 'Alamat maksimal 500 karakter.';

        // Cek duplikat TikTok handle
        if ($handle !== '') {
            $editId = (int)($_POST['id'] ?? 0);
            $s = db()->prepare('SELECT id FROM mitra WHERE tiktok_handle = ? AND id != ?');
            $s->execute([$handle, $editId]);
            if ($s->fetch()) $errors[] = 'Akun TikTok @' . $handle . ' sudah terdaftar.';
        }

        // Cek duplikat nama+produk
        if ($nama !== '' && $produk !== '') {
            $editId = (int)($_POST['id'] ?? 0);
            $s = db()->prepare('SELECT id FROM mitra WHERE nama = ? AND produk = ? AND id != ?');
            $s->execute([$nama, $produk, $editId]);
            if ($s->fetch()) $errors[] = 'Nama mitra ini sudah terdaftar di produk yang sama.';
        }

        if (count($errors) > 0) {
            $error = implode('<br>', array_map(function($e){ return htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); }, $errors));
        } else {
            if (!empty($_POST['id'])) {
                // [DIUBAH] Menambahkan user_id=? pada query UPDATE
                db()->prepare('UPDATE mitra SET user_id=?, nama=?, produk=?, tiktok_handle=?, tiktok_url=?, instagram_url=?, instagram_handle=?, alamat=? WHERE id=?')
                    ->execute([$assignUserId, $nama, $produk, $handle ?: null, $tiktok, $ig, $igHandle, $alamat, (int)$_POST['id']]);
                flash('success', 'Mitra diperbarui');
            } else {
                // [DIUBAH] Menggunakan $assignUserId bukan $uid
                db()->prepare('INSERT INTO mitra (user_id, nama, produk, tiktok_handle, tiktok_url, instagram_url, instagram_handle, alamat) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([$assignUserId, $nama, $produk, $handle ?: null, $tiktok, $ig, $igHandle, $alamat]);
                flash('success', 'Mitra ditambahkan');
            }
            redirect('mitra.php');
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            db()->prepare('DELETE FROM mitra WHERE id = ?')->execute([$id]);
            flash('success', 'Mitra dihapus');
        }
        redirect('mitra.php');
    }
}

// Search
$q = trim($_GET['q'] ?? '');
$where = '';
$params = [];
if ($q !== '') {
    $where = 'WHERE nama LIKE ? OR produk LIKE ? OR tiktok_handle LIKE ? OR instagram_handle LIKE ? OR alamat LIKE ?';
    $like = '%' . $q . '%';
    $params = [$like, $like, $like, $like, $like];
}
// JOIN dengan table users tetap ada, sekarang mencerminkan "Pemilik Mitra"
$stmt = db()->prepare("SELECT m.*, u.username AS input_by FROM mitra m LEFT JOIN users u ON u.id = m.user_id $where ORDER BY m.produk ASC, m.nama ASC");
$stmt->execute($params);
$mitra = $stmt->fetchAll();

// Hitung konten TikTok
$stmt = db()->query('SELECT author_unique_id, COUNT(*) AS c FROM videos GROUP BY author_unique_id');
$contentCounts = [];
foreach ($stmt->fetchAll() as $r) {
    $contentCounts[$r['author_unique_id']] = (int)$r['c'];
}

// Hitung konten IG
$stmt = db()->query('SELECT ig_username, COUNT(*) AS c FROM ig_posts GROUP BY ig_username');
$igContentCounts = [];
foreach ($stmt->fetchAll() as $r) {
    $igContentCounts[$r['ig_username']] = (int)$r['c'];
}

require __DIR__ . '/layouts/header.php';
?>

<!-- STYLE UNTUK POP-UP MODAL (DIPERBAIKI AGAR TEKS & BACKGROUND TERBACA JELAS) -->
<style>
.modal-overlay {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.75);
    display: none; 
    align-items: center;
    justify-content: center;
    z-index: 9999;
}
.modal-box {
    background-color: var(--surface-1, #ffffff);
    color: var(--text-color, #222222); 
    border: 1px solid var(--border, #cccccc);
    padding: 24px;
    border-radius: 12px;
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
}
.modal-title {
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 1.25rem;
    color: inherit;
}
.modal-box label {
    font-weight: 500;
    margin-bottom: 6px;
    display: inline-block;
    color: inherit;
}

@media (prefers-color-scheme: dark) {
    .modal-box { 
        background-color: var(--surface-2, #1e1e1e); 
        color: var(--text-color, #f5f5f5);
        border-color: var(--border, #444444);
    }
}
</style>

<div class="card">
    <div class="card-head">
        <div>
            <h2 class="card-title">Direktori Akun TikTok Mitra</h2>
            <p class="card-desc" style="margin:0">Daftar mitra &amp; akun TikTok-nya. Kolom <em>Konten</em> = jumlah konten yang sudah berhasil di-scrape.</p>
        </div>
        <?php if ($admin): ?>
            <!-- Tombol Tambah -->
            <button class="btn btn-primary" type="button" onclick="openModal()">+ Tambah Mitra</button>
        <?php endif; ?>
    </div>

    <form method="get" action="mitra.php" class="filter-form" style="margin-bottom:18px">
        <div>
            <label for="q">Cari</label>
            <input type="text" id="q" name="q" class="form-control" placeholder="nama / produk / handle / alamat" value="<?= e($q) ?>">
        </div>
        <button type="submit" class="btn btn-ghost">Cari</button>
        <?php if ($q !== ''): ?><a href="mitra.php" class="btn btn-ghost">Reset</a><?php endif; ?>
    </form>

    <div class="table-scroll">
        <table class="table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Produk</th>
                    <th>Akun TikTok</th>
                    <th>Instagram</th>
                    <th>Alamat</th>
                    <th>Pemilik (User)</th> <!-- Judul Kolom Diubah -->
                    <th class="ta-right">TikTok</th>
                    <th class="ta-right">IG</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (count($mitra) === 0): ?>
                <tr><td colspan="9" class="empty">Tidak ada mitra.</td></tr>
            <?php endif; ?>
            <?php foreach ($mitra as $m): ?>
                <tr>
                    <td class="cell-primary"><?= e($m['nama'] ?: '—') ?></td>
                    <td>
                        <?php if ($m['produk'] !== ''): ?><span class="mitra-tag"><?= e($m['produk']) ?></span><?php else: ?><span class="cell-sub">—</span><?php endif; ?>
                    </td>
                    <td>
                        <?php if ($m['tiktok_handle'] !== ''): ?>
                            <a href="https://www.tiktok.com/@<?= e($m['tiktok_handle']) ?>" target="_blank" rel="noopener">@<?= e($m['tiktok_handle']) ?></a>
                        <?php else: ?><span class="cell-sub">—</span><?php endif; ?>
                    </td>
                    <td>
                        <?php if ($m['instagram_handle'] !== ''): ?>
                            <a href="https://www.instagram.com/<?= e($m['instagram_handle']) ?>" target="_blank" rel="noopener">@<?= e($m['instagram_handle']) ?></a>
                        <?php elseif ($m['instagram_url'] !== ''): ?>
                            <a href="<?= e($m['instagram_url']) ?>" target="_blank" rel="noopener">IG</a>
                        <?php else: ?><span class="cell-sub">—</span><?php endif; ?>
                    </td>
                    <td class="cell-sub" style="max-width:240px"><?= e(mb_strimwidth((string)$m['alamat'], 0, 80, '…')) ?></td>
                    
                    <!-- Menampilkan Pemilik (User ID) -->
                    <td class="cell-sub"><span class="badge" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd;"><?= e($m['input_by'] ?? '—') ?></span></td>
                    
                    <td class="ta-right">
                        <?php $c = $contentCounts[$m['tiktok_handle']] ?? 0; ?>
                        <?php if ($c > 0): ?>
                            <span class="badge badge-success"><?= (int)$c ?></span>
                        <?php else: ?>
                            <span class="cell-sub">0</span>
                        <?php endif; ?>
                    </td>
                    <td class="ta-right">
                        <?php
                            $igCount = 0;
                            if ($m['instagram_handle'] !== '' && isset($igContentCounts[$m['instagram_handle']])) {
                                $igCount = $igContentCounts[$m['instagram_handle']];
                            }
                        ?>
                        <?php if ($igCount > 0): ?>
                            <span class="badge badge-success"><?= (int)$igCount ?></span>
                        <?php else: ?>
                            <span class="cell-sub">0</span>
                        <?php endif; ?>
                    </td>
                    <td class="ta-right" style="white-space:nowrap">
                        <?php if ($m['tiktok_handle'] !== ''): ?>
                            <a href="scrape.php?handle=<?= e($m['tiktok_handle']) ?>&mitra=<?= e($m['produk']) ?>" class="btn btn-primary btn-sm">TikTok</a>
                        <?php endif; ?>
                        <?php if ($m['instagram_handle'] !== ''): ?>
                            <a href="ig-scrape.php?handle=<?= e($m['instagram_handle']) ?>&mitra=<?= e($m['produk']) ?>" class="btn btn-sm" style="background:linear-gradient(45deg,#833AB4,#FD1D1D,#F77737);border:none;color:#fff">IG</a>
                        <?php endif; ?>
                        
                        <?php if ($admin): ?>
                            <?php 
                                $tiktokVal = $m['tiktok_url'] ?: $m['tiktok_handle'];
                                $igVal = $m['instagram_url'] ?: $m['instagram_handle'];
                            ?>
                            <!-- [DIUBAH] Menyelipkan parameter ke-2 (user_id) ke fungsi openModal -->
                            <button type="button" class="btn btn-ghost btn-sm" onclick='openModal(
                                <?= (int)$m['id'] ?>,
                                <?= (int)$m['user_id'] ?>,
                                <?= json_encode($m['nama']) ?>,
                                <?= json_encode($m['produk']) ?>,
                                <?= json_encode($tiktokVal) ?>,
                                <?= json_encode($igVal) ?>,
                                <?= json_encode($m['alamat']) ?>
                            )'>Edit</button>

                            <form method="post" action="mitra.php" class="inline-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Hapus mitra ini?')">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($admin): ?>
<!-- HTML UNTUK POP-UP MODAL (FORM TAMBAH & EDIT) -->
<div id="modalOverlay" class="modal-overlay" style="display: <?= $error ? 'flex' : 'none' ?>;">
    <div class="modal-box">
        <h3 id="modalTitle" class="modal-title"><?= !empty($_POST['id']) ? 'Edit' : 'Tambah' ?> Mitra</h3>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" style="margin-bottom:15px;"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="post" action="mitra.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" id="formId" value="<?= e($_POST['id'] ?? '') ?>">
            
            <!-- [BARU] Field Dropdown untuk memilih User/Pemilik Mitra -->
            <div class="form-group" style="margin-bottom: 15px; background: var(--surface-2, #f9fafb); padding: 12px; border-radius: 8px; border: 1px solid var(--border, #e5e7eb);">
                <label for="assign_user_id" style="color: #0369a1;">Plotting Pemilik Mitra (User ID)</label>
                <select id="assign_user_id" name="assign_user_id" class="form-control">
                    <?php foreach ($userList as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= (isset($_POST['assign_user_id']) && $_POST['assign_user_id'] == $u['id']) ? 'selected' : '' ?>>
                            <?= e($u['username']) ?> — (Role: <?= strtoupper(e($u['role'])) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <small style="color: var(--text-muted, #6b7280); display: block; margin-top: 4px;">Pilih akun user yang akan mengelola / memiliki data mitra ini.</small>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama pemilik/operator" value="<?= e($_POST['nama'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="produk">Produk</label>
                    <input type="text" id="produk" name="produk" class="form-control" placeholder="Be Nice Coffee" value="<?= e($_POST['produk'] ?? '') ?>">
                </div>
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label for="tiktok">Akun TikTok (link atau @handle)</label>
                    <input type="text" id="tiktok" name="tiktok" class="form-control" placeholder="https://www.tiktok.com/@handle" value="<?= e($_POST['tiktok'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="instagram">Akun Instagram</label>
                    <input type="text" id="instagram" name="instagram" class="form-control" placeholder="https://www.instagram.com/..." value="<?= e($_POST['instagram'] ?? '') ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <textarea id="alamat" name="alamat" class="form-control" rows="2" placeholder="Alamat lengkap outlet"><?= e($_POST['alamat'] ?? '') ?></textarea>
            </div>
            <div class="form-actions" style="margin-top: 20px; display:flex; gap:10px;">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button>
            </div>
        </form>
    </div>
</div>

<!-- JAVASCRIPT UNTUK MENGONTROL POP-UP -->
<script>
// [DIUBAH] Tambah parameter `userId` sebagai parameter kedua
function openModal(id = '', userId = '', nama = '', produk = '', tiktok = '', ig = '', alamat = '') {
    // Ubah Judul Pop-up
    document.getElementById('modalTitle').innerText = id ? 'Edit Mitra' : 'Tambah Mitra';
    
    // Isi Form
    document.getElementById('formId').value = id;
    document.getElementById('nama').value = nama;
    document.getElementById('produk').value = produk;
    document.getElementById('tiktok').value = tiktok;
    document.getElementById('instagram').value = ig;
    document.getElementById('alamat').value = alamat;
    
    // [BARU] Set Dropdown Pemilik
    if (id && userId) {
        // Jika mode edit, set dropdown ke userId milik data tersebut
        document.getElementById('assign_user_id').value = userId;
    } else {
        // Jika mode tambah, default-kan kembali ke ID admin yang sedang login
        document.getElementById('assign_user_id').value = '<?= $uid ?>';
    }
    
    // Tampilkan Modal
    document.getElementById('modalOverlay').style.display = 'flex';
}

function closeModal() {
    // Sembunyikan Modal
    document.getElementById('modalOverlay').style.display = 'none';
    
    // Jika sedang ada error, reload halaman agar error-nya hilang dan URL kembali bersih
    <?php if ($error): ?>
    window.location.href = 'mitra.php';
    <?php endif; ?>
}
</script>
<?php endif; ?>

<?php require __DIR__ . '/layouts/footer.php'; ?>