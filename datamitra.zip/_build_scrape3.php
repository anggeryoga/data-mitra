<?php
$f = __DIR__ . '/scrape.php';
$html = <<<'HTML'

<div class="platform-card">
  <a href="scrape.php" class="platform-btn active-platform" style="background:var(--tt-dark);color:#fff">
    <div class="p-icon">&#9654;</div>
    <div class="p-title">TikTok</div>
    <div class="p-desc">Scrape semua video dari akun TikTok</div>
  </a>
  <a href="ig-scrape.php" class="platform-btn" style="background:linear-gradient(45deg,#833AB4,#FD1D1D,#F77737);color:#fff">
    <div class="p-icon">&#9679;</div>
    <div class="p-title">Instagram</div>
    <div class="p-desc">Scrape semua post dari akun Instagram</div>
  </a>
</div>

<div class="flow-steps">
  <div class="flow-item active"><div class="flow-num">1</div><div class="flow-text">Pilih Mitra</div></div>
  <div class="flow-item"><div class="flow-num">2</div><div class="flow-text">Cek Handle TikTok</div></div>
  <div class="flow-item"><div class="flow-num">3</div><div class="flow-text">Scrape &amp; Simpan</div></div>
</div>

<div class="grid-2">
<div class="form-card">
  <h3><span class="badge-tt">TT</span> Scrape TikTok</h3>
  <p class="form-desc">Pilih mitra, handle TikTok auto-fill. Scrape semua video.</p>
  <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="scrape.php" id="tt-form">
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="mitra-select" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem">Pilih Mitra</label>
      <div class="pk-select-wrap">
        <select id="mitra-select" name="mitra_name" required>
          <option value="">-- Pilih mitra --</option>
          <?php foreach ($brandGroups as $brand => $mitras): ?>
            <optgroup label="<?= e($brand) ?>">
            <?php foreach ($mitras as $m):
              $tt = $m['tt_handle'] !== '' ? '@'.$m['tt_handle'] : '(belum ada TikTok)';
            ?>
              <option value="<?= e($m['nama']) ?>" data-tt="<?= e($m['tt_handle']) ?>" <?= ($preMitra === $m['nama']) ? 'selected' : '' ?>>
                <?= e($m['nama']) ?> &mdash; <?= e($tt) ?>
              </option>
            <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </div>
      <small class="form-hint" style="margin-top:.3rem">Mitra tanpa TikTok handle bisa dipilih &mdash; isi handle manual di bawah.</small>
    </div>
    <div class="form-group">
      <label for="handle" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem">Handle TikTok</label>
      <div class="pk-handle-row">
        <span class="pk-handle-prefix">@</span>
        <input type="text" id="handle" name="handle" class="pk-handle-input" required placeholder="username_tiktok" value="<?= e($_POST['handle'] ?? $preHandle) ?>">
      </div>
      <small class="form-hint" style="margin-top:.3rem">Otomatis terisi saat pilih mitra. Bisa diedit manual.</small>
    </div>
    <button type="submit" class="pk-btn" id="btn-scrape">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
      Scrape Semua Video
    </button>
  </form>

  <div class="scrape-overlay" id="scrape-overlay">
    <div class="overlay-card">
      <div class="spinner"></div>
      <div class="overlay-title">Mengambil semua video...</div>
      <div class="overlay-status" id="overlay-status">Menghubungi ScrapeCreators...</div>
      <div class="overlay-timer"><span id="overlay-timer">0</span><small> dtk</small></div>
      <div class="overlay-note">Akun banyak video butuh waktu lama.<br>Jangan tutup tab ini.</div>
    </div>
  </div>

  <?php if ($result): ?>
  <div class="result-box tt-result-box" style="margin-top:1.2rem">
    <h3 class="result-title">Hasil Scrape: @<?= e($result['handle']) ?></h3>
    <div class="result-meta">
      <?php if ($result['mitra'] !== ''): ?><span class="result-meta-item"><span class="muted">Mitra</span><strong><?= e($result['mitra']) ?></strong></span><?php endif; ?>
      <span class="result-meta-item"><span class="muted">Akun</span><strong><?= e($result['nickname']) ?></strong></span>
      <span class="result-meta-item"><span class="muted">Video profil</span><strong><?= (int)$result['profile_total'] ?></strong></span>
      <span class="result-meta-item"><span class="muted">Terambil</span><strong><?= (int)$result['fetched'] ?></strong></span>
      <span class="result-meta-item"><span class="muted">Baru</span><strong><?= (int)$result['inserted'] ?></strong></span>
      <span class="result-meta-item"><span class="muted">Total views</span><strong><?= format_number((int)$result['total_views']) ?></strong></span>
      <span class="result-meta-item"><span class="muted">Credits</span><strong><?= (int)$result['credits'] ?></strong></span>
    </div>
    <?php if (!$result['complete']): ?><div class="alert alert-warning" style="margin-top:12px">Pagination belum tuntas. Scrape ulang untuk lanjut.</div><?php endif; ?>
    <?php if (!$result['stopped_early'] && $result['fetched'] === 0): ?><div class="alert alert-info" style="margin-top:12px">Tidak ada video baru.</div><?php endif; ?>
    <div style="margin-top:14px"><a href="akun.php?akun=<?= e($result['author_uid']) ?>" class="btn btn-ghost">Lihat Rekap Bulanan</a></div>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <h2 class="card-title">Riwayat Scrape</h2>
  <?php if (count($history) === 0): ?>
    <div class="empty">Belum ada scrape TikTok.</div>
  <?php else: ?>
    <table class="history-table">
      <thead><tr><th>Akun</th><th class="ta-right">Video</th><th class="ta-right">Views</th><th>Oleh</th><th>Waktu</th></tr></thead>
      <tbody>
        <?php foreach ($history as $h): ?>
        <tr>
          <td><div class="cell-primary"><span class="badge-tt">TT</span>@<?= e($h['handle']) ?></div><div class="cell-sub"><?= e($h['mitra_name']) ?></div></td>
          <td class="ta-right"><strong><?= (int)$h['total_videos'] ?></strong></td>
          <td class="ta-right"><?= format_number((int)$h['total_views']) ?></td>
          <td class="cell-sub"><?= e($h['username']) ?></td>
          <td class="cell-sub"><?= e(date('d M Y H:i', strtotime($h['created_at']))) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
</div>

<?php if (count($ttAccounts) > 0): ?>
<div class="batch-card">
  <h3><span class="badge-tt">BATCH</span> Scrape Semua Akun TikTok</h3>
  <p style="font-size:.85rem;color:#64748b;margin:0 0 1rem">Scrape <?= count($ttAccounts) ?> akun TikTok mitra secara berurutan.</p>
  <button type="button" class="pk-btn" id="btn-batch" onclick="startBatch()">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
    Scrape Semua (<?= count($ttAccounts) ?> akun)
  </button>
  <div class="batch-list" id="batch-list" style="display:none;margin-top:1rem">
    <?php $idx = 0; foreach ($ttAccounts as $acc): $idx++; ?>
    <div class="batch-item" id="batch-item-<?= $idx ?>" data-handle="<?= e($acc['tt_handle']) ?>" data-name="<?= e($acc['nama']) ?>">
      <div class="batch-idx"><?= $idx ?></div>
      <div class="batch-name"><?= e($acc['nama']) ?></div>
      <div class="batch-handle">@<?= e($acc['tt_handle']) ?></div>
      <div class="batch-status" id="batch-status-<?= $idx ?>"></div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="batch-summary" id="batch-summary" style="display:none">
    <div class="stat"><span class="stat-label">Selesai:</span><span class="stat-val" id="batch-done">0</span></div>
    <div class="stat"><span class="stat-label">Gagal:</span><span class="stat-val" id="batch-fail">0</span></div>
    <div class="stat"><span class="stat-label">Total video:</span><span class="stat-val" id="batch-videos">0</span></div>
    <div class="stat"><span class="stat-label">Credits:</span><span class="stat-val" id="batch-credits">0</span></div>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/layouts/footer.php'; ?>
<script>
(function(){
  var sel = document.getElementById('mitra-select');
  var handleInput = document.getElementById('handle');
  if (sel && handleInput) {
    sel.addEventListener('change', function() {
      var opt = sel.options[sel.selectedIndex];
      var tt = opt ? opt.getAttribute('data-tt') : '';
      if (tt && tt !== '') { handleInput.value = tt; }
    });
  }

  var form = document.getElementById('tt-form');
  var overlay = document.getElementById('scrape-overlay');
  var timerEl = document.getElementById('overlay-timer');
  var btn = document.getElementById('btn-scrape');
  if (form && overlay) {
    form.addEventListener('submit', function(e) {
      if (!handleInput.value.trim()) { e.preventDefault(); return; }
      overlay.style.display = 'flex';
      btn.disabled = true;
      var sec = 0;
      setInterval(function() { sec++; if (timerEl) timerEl.textContent = sec; }, 1000);
    });
  }

  window.startBatch = function() {
    var items = document.querySelectorAll('#batch-list .batch-item');
    if (!items.length) return;
    var btnBatch = document.getElementById('btn-batch');
    var list = document.getElementById('batch-list');
    var summary = document.getElementById('batch-summary');
    btnBatch.disabled = true;
    btnBatch.textContent = 'Sedang scraping...';
    list.style.display = 'block';
    summary.style.display = 'flex';
    var csrf = document.querySelector('input[name="csrf_token"]');
    var csrfToken = csrf ? csrf.value : '';
    var done=0, fail=0, totalVideos=0, totalCredits=0, idx=0;
    function scrapeNext() {
      if (idx >= items.length) {
        btnBatch.textContent = 'Selesai! ' + done + ' berhasil, ' + fail + ' gagal';
        btnBatch.disabled = false;
        return;
      }
      var item = items[idx];
      var handle = item.getAttribute('data-handle');
      var name = item.getAttribute('data-name');
      var statusEl = document.getElementById('batch-status-' + (idx + 1));
      item.classList.add('active');
      statusEl.innerHTML = '<div class="spinner-sm"></div>';
      var fd = new FormData();
      fd.append('csrf_token', csrfToken);
      fd.append('handle', handle);
      fd.append('mitra_name', name);
      fetch('api/tiktok-batch-scrape.php', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(data){
          item.classList.remove('active');
          if (data.success) {
            item.classList.add('done');
            statusEl.innerHTML = '<span style="color:#16a34a;font-weight:700">&#10003;</span>';
            done++; totalVideos += (data.total_videos||0); totalCredits += (data.credits||0);
          } else {
            item.classList.add('fail');
            statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700">&#10007;</span>';
            fail++;
          }
        }).catch(function(){
          item.classList.remove('active');
          item.classList.add('fail');
          statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700">&#10007;</span>';
          fail++;
        }).finally(function(){
          document.getElementById('batch-done').textContent = done;
          document.getElementById('batch-fail').textContent = fail;
          document.getElementById('batch-videos').textContent = totalVideos;
          document.getElementById('batch-credits').textContent = totalCredits;
          idx++; scrapeNext();
        });
    }
    scrapeNext();
  };
})();
</script>
HTML;

file_put_contents($f, file_get_contents($f) . $html);
echo "Final: " . filesize($f) . "\n";
