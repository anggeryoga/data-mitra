<?php
/**
 * akun.php — Detail per akun: pilih akun, lihat jumlah konten tiap bulan + list video.
 * Admin lihat semua akun. User lihat hanya akun dari videonya sendiri.
 */
require __DIR__ . '/config.php';
require_login();

$pageTitle = 'Per Akun / Bulan';
$active    = 'akun';

$isAdmin = is_admin();

// Hapus video (admin semua, user milik sendiri)
if (isset($_GET['delete'])) {
    require_csrf();
    $delId = (int)$_GET['delete'];
    if ($isAdmin) {
        db()->prepare('DELETE FROM videos WHERE id = ?')->execute([$delId]);
    } else {
        db()->prepare('DELETE FROM videos WHERE id = ? AND user_id = ?')->execute([$delId, (int)(current_user()['id'] ?? 0)]);
    }
    flash('success', 'Video dihapus');
    redirect('akun.php' . ($_GET['akun'] ?? '' ? '?akun=' . urlencode((string)$_GET['akun']) : ''));
}
$uid     = (int)(current_user()['id'] ?? 0);

$scopeWhere  = '';
$scopeParams = [];
if (!$isAdmin) {
    $scopeWhere  = ' AND v.user_id = ?';
    $scopeParams[] = $uid;
}

// Daftar akun
$stmt = db()->prepare("
    SELECT v.author_unique_id,
           MAX(v.author_nickname) AS author_nickname,
           MAX(v.mitra_name) AS mitra_name,
           COUNT(*) AS total_konten,
           COALESCE(SUM(v.play_count),0) AS total_views
    FROM videos v
    WHERE v.author_unique_id <> '' $scopeWhere
    GROUP BY v.author_unique_id
    ORDER BY total_views DESC
");
$stmt->execute($scopeParams);
$akunList = $stmt->fetchAll();

// Akun terpilih
$fAkun = trim($_GET['akun'] ?? '');
if ($fAkun === '' && count($akunList) > 0) {
    $fAkun = $akunList[0]['author_unique_id'];
}

$detail = null;
if ($fAkun !== '') {
    // Pastikan akun milik scope user ini
    $stmt = db()->prepare("
        SELECT v.author_unique_id, MAX(v.author_nickname) AS author_nickname, MAX(v.mitra_name) AS mitra_name
        FROM videos v
        WHERE v.author_unique_id = ? $scopeWhere
        GROUP BY v.author_unique_id
    ");
    $stmt->execute(array_merge([$fAkun], $scopeParams));
    $detail = $stmt->fetch();

    if ($detail) {
        // Agregat per bulan
        $stmt = db()->prepare("
            SELECT DATE_FORMAT(FROM_UNIXTIME(v.create_time), '%Y-%m') AS bulan,
                   COUNT(*) AS jml_konten,
                   COALESCE(SUM(v.play_count),0) AS views,
                   COALESCE(SUM(v.digg_count),0) AS likes,
                   COALESCE(SUM(v.comment_count),0) AS comments,
                   COALESCE(SUM(v.share_count),0) AS shares
            FROM videos v
            WHERE v.author_unique_id = ? $scopeWhere
            GROUP BY bulan
            ORDER BY bulan DESC
        ");
        $stmt->execute(array_merge([$fAkun], $scopeParams));
        $perBulan = $stmt->fetchAll();

        // List video
        $stmt = db()->prepare("
            SELECT v.*, u.username
            FROM videos v JOIN users u ON u.id = v.user_id
            WHERE v.author_unique_id = ? $scopeWhere
            ORDER BY v.create_time DESC
        ");
        $stmt->execute(array_merge([$fAkun], $scopeParams));
        $videos = $stmt->fetchAll();
    }
}

require __DIR__ . '/layouts/header.php';
?>

<div class="card">
    <form method="get" action="akun.php" class="filter-form">
        <label for="akun">Pilih Akun</label>
        <select name="akun" id="akun" class="form-control">
            <?php foreach ($akunList as $a): ?>
                <option value="<?= e($a['author_unique_id']) ?>" <?= $fAkun === $a['author_unique_id'] ? 'selected' : '' ?>>
                    @<?= e($a['author_unique_id']) ?> — <?= (int)$a['total_konten'] ?> konten
                </option>
            <?php endforeach; ?>
            <?php if (count($akunList) === 0): ?>
                <option value="">Belum ada akun</option>
            <?php endif; ?>
        </select>
        <button type="submit" class="btn btn-primary">Lihat</button>
    </form>
</div>

<?php if ($detail): ?>
    <div class="stat-grid">
        <div class="stat-card">
            <span class="stat-label">Akun</span>
            <span class="stat-value" style="font-size:1.3rem">@<?= e($detail['author_unique_id']) ?></span>
            <span class="stat-sub">
                <?= $detail['mitra_name'] !== '' ? e($detail['mitra_name']) . ' · ' : '' ?><?= e($detail['author_nickname']) ?>
            </span>
        </div>
        <?php
        $totKonten = 0; $totViews = 0; $totLikes = 0;
        foreach ($perBulan as $b) { $totKonten += (int)$b['jml_konten']; $totViews += (int)$b['views']; $totLikes += (int)$b['likes']; }
        ?>
        <div class="stat-card">
            <span class="stat-label">Total Konten</span>
            <span class="stat-value"><?= format_number($totKonten) ?></span>
            <span class="stat-sub">yang ter-track</span>
        </div>
        <div class="stat-card">
            <span class="stat-label">Total Views</span>
            <span class="stat-value"><?= format_compact($totViews) ?></span>
            <span class="stat-sub"><?= format_number($totViews) ?> views</span>
        </div>
        <div class="stat-card">
            <span class="stat-label">Total Likes</span>
            <span class="stat-value"><?= format_compact($totLikes) ?></span>
            <span class="stat-sub"><?= format_number($totLikes) ?> likes</span>
        </div>
    </div>

    <div class="card">
        <h2 class="card-title">Jumlah Konten per Bulan</h2>
        <?php if (count($perBulan) === 0): ?>
            <div class="empty">Belum ada data bulanan.</div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th class="ta-right">Jumlah Konten</th>
                        <th class="ta-right">Views</th>
                        <th class="ta-right">Likes</th>
                        <th class="ta-right">Komentar</th>
                        <th class="ta-right">Share</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($perBulan as $b): ?>
                    <tr>
                        <td><strong><?= e(date('F Y', strtotime($b['bulan'] . '-01'))) ?></strong></td>
                        <td class="ta-right"><strong><?= (int)$b['jml_konten'] ?></strong></td>
                        <td class="ta-right"><?= format_number((int)$b['views']) ?></td>
                        <td class="ta-right"><?= format_number((int)$b['likes']) ?></td>
                        <td class="ta-right"><?= format_number((int)$b['comments']) ?></td>
                        <td class="ta-right"><?= format_number((int)$b['shares']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2 class="card-title">List Video</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Konten</th>
                    <th>Tanggal</th>
                    <th class="ta-right">Views</th>
                    <th class="ta-right">Likes</th>
                    <th class="ta-right">Komentar</th>
                    <th class="ta-right">Share</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php if (count($videos) === 0): ?>
                <tr><td colspan="7" class="empty">Tidak ada video.</td></tr>
            <?php endif; ?>
            <?php foreach ($videos as $v): ?>
                <tr>
                    <td>
                        <a href="<?= e($v['url']) ?>" target="_blank" rel="noopener" class="cell-primary">
                            <?= e(mb_strimwidth((string)($v['title'] ?: '(tanpa deskripsi)'), 0, 60, '…')) ?>
                        </a>
                    </td>
                    <td class="cell-sub"><?= e(date('d M Y', (int)$v['create_time'])) ?></td>
                    <td class="ta-right"><strong><?= format_number((int)$v['play_count']) ?></strong></td>
                    <td class="ta-right"><?= format_number((int)$v['digg_count']) ?></td>
                    <td class="ta-right"><?= format_number((int)$v['comment_count']) ?></td>
                    <td class="ta-right"><?= format_number((int)$v['share_count']) ?></td>
                    <td class="ta-right">
                        <a href="akun.php?akun=<?= e($fAkun) ?>&delete=<?= (int)$v['id'] ?>&csrf_token=<?= e(csrf_token()) ?>"
                           class="btn btn-ghost btn-sm"
                           onclick="return confirm('Hapus video ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="card"><div class="empty">Akun tidak ditemukan atau kamu tidak punya akses.</div></div>
<?php endif; ?>

<?php require __DIR__ . '/layouts/footer.php'; ?>