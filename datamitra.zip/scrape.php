<?php
require __DIR__ . '/config.php';
require_login();
$pageTitle = 'Scrape TikTok';
$active    = 'scrape';
require_once __DIR__ . '/includes/ScrapeCreators.php';

$uid = (int)(current_user()['id'] ?? 0);
$error = ''; $result = null;
$preHandle = trim($_GET['handle'] ?? '');
$preMitra  = trim($_GET['mitra'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $handle = ltrim(trim($_POST['handle'] ?? ''), '@');
    $mitra  = trim($_POST['mitra_name'] ?? '');
    
    if ($handle === '') { $error = 'Handle TikTok wajib diisi'; }
    elseif (!preg_match('#^[A-Za-z0-9._-]+$#', $handle)) { $error = 'Format handle tidak valid'; }
    else {
        $sc = new ScrapeCreators();
        $prof = $sc->profile($handle);
        if ($prof === null) { $error = 'Gagal ambil profil. Cek handle & koneksi.'; }
        else {
            $authorUid  = (string)($prof['user']['uniqueId'] ?? $prof['user']['unique_id'] ?? $handle);
            $authorNick = (string)($prof['user']['nickname'] ?? $handle);
            $profTotal  = (int)($prof['stats']['videoCount'] ?? $prof['statsV2']['videoCount'] ?? 0);
            $userId     = (string)($prof['user']['id'] ?? '');
            
            $existingIds = [];
            $stmt = db()->prepare('SELECT aweme_id FROM videos WHERE author_unique_id = ? AND user_id = ?');
            $stmt->execute([$authorUid, $uid]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $aid) { $existingIds[$aid] = true; }
            
            $fetched = $sc->fetchAllVideos($handle, ($userId !== '' ? $userId : null), [
                'stopOnExisting' => count($existingIds) > 0,
                'existingIds' => $existingIds,
            ]);
            
            $videos = $fetched['videos'];
            if (count($videos) === 0) { $error = 'Tidak ada video yang berhasil diambil.'; }
            else {
                $inserted = 0; $updated = 0; $totalViews = 0;
                $ins = db()->prepare('INSERT INTO videos (user_id,aweme_id,url,author_unique_id,author_nickname,mitra_name,title,cover_url,create_time,play_count,digg_count,comment_count,share_count) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE url=VALUES(url),author_unique_id=VALUES(author_unique_id),author_nickname=VALUES(author_nickname),mitra_name=VALUES(mitra_name),title=VALUES(title),cover_url=VALUES(cover_url),create_time=VALUES(create_time),play_count=VALUES(play_count),digg_count=VALUES(digg_count),comment_count=VALUES(comment_count),share_count=VALUES(share_count)');
                
                foreach ($videos as $v) {
                    $awemeId = (string)($v['aweme_id'] ?? ''); if ($awemeId === '') continue;
                    $url = (string)($v['url'] ?? $v['share_url'] ?? '');
                    $aUid = (string)($v['author']['unique_id'] ?? $v['author']['uniqueId'] ?? $authorUid);
                    $aNick = (string)($v['author']['nickname'] ?? $authorNick);
                    $desc = (string)($v['desc'] ?? '');
                    $cTime = (int)($v['create_time'] ?? 0);
                    $stat = $v['statistics'] ?? [];
                    $play = (int)($stat['play_count'] ?? 0); $digg = (int)($stat['digg_count'] ?? 0);
                    $comment = (int)($stat['comment_count'] ?? 0); $share = (int)($stat['share_count'] ?? 0);
                    $totalViews += $play;
                    
                    $ins->execute([$uid,$awemeId,$url,$aUid,$aNick,$mitra,$desc,'',$cTime,$play,$digg,$comment,$share]);
                    $rc = $ins->rowCount(); if ($rc===1) $inserted++; elseif ($rc===2) $updated++;
                }
                
                db()->prepare('INSERT INTO scrapes (user_id,handle,mitra_name,author_unique_id,author_nickname,total_videos,total_views,credits_used,status,error_message) VALUES (?,?,?,?,?,?,?,?,?,?)')->execute([$uid,$handle,$mitra,$authorUid,$authorNick,count($videos),$totalViews,(int)$fetched['credits'],'success',null]);
                
                $result = ['handle'=>$handle,'mitra'=>$mitra,'nickname'=>$authorNick,'author_uid'=>$authorUid,'profile_total'=>$profTotal,'fetched'=>count($videos),'inserted'=>$inserted,'updated'=>$updated,'total_views'=>$totalViews,'pages'=>(int)$fetched['pages'],'credits'=>(int)$fetched['credits'],'complete'=>(bool)$fetched['complete'],'stopped_early'=>(bool)($fetched['stopped_early']??false)];
            }
        }
    }
}

$scopeWhere = ''; $scopeParams = [];
if (!is_admin()) { $scopeWhere = ' AND s.user_id = ?'; $scopeParams[] = $uid; }
$stmt = db()->prepare("SELECT s.*, u.username FROM scrapes s JOIN users u ON u.id = s.user_id WHERE 1=1 $scopeWhere ORDER BY s.created_at DESC LIMIT 20");
$stmt->execute($scopeParams);
$history = $stmt->fetchAll();

$mitraRows = db()->query("SELECT id, nama, produk, COALESCE(tiktok_handle,'') AS tt_handle FROM mitra WHERE nama != '' ORDER BY produk, nama")->fetchAll(PDO::FETCH_ASSOC);
$brandGroups = [];
$ttAccounts = [];
foreach ($mitraRows as $m) {
    $brand = $m['produk'] !== '' ? $m['produk'] : 'Tanpa Brand';
    $brandGroups[$brand][] = $m;
    if ($m['tt_handle'] !== '') { $ttAccounts[] = $m; }
}

require __DIR__ . '/layouts/header.php';
?>
<style>
:root{--tt-dark:#0f172a;--tt-pink:#FE2C55;--tt-cyan:#25F4EE}
.platform-card{display:flex;gap:1rem;margin-bottom:1.5rem}
.platform-btn{flex:1;padding:1.2rem;border-radius:12px;text-align:center;text-decoration:none!important;border:2px solid transparent;transition:transform .12s,box-shadow .12s}
.platform-btn:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(0,0,0,.1)}
.platform-btn.active-platform{box-shadow:0 2px 12px rgba(0,0,0,.12);border-color:rgba(255,255,255,.3)}
.platform-btn .p-icon{font-size:1.5rem;margin-bottom:.3rem}
.platform-btn .p-title{font-weight:700;font-size:1.05rem}
.platform-btn .p-desc{font-size:.78rem;opacity:.8;margin-top:.2rem}
.flow-steps{display:flex;gap:.5rem;margin-bottom:1.5rem}
.flow-item{flex:1;display:flex;align-items:center;gap:.6rem;padding:.8rem 1rem;background:#fff;border:1px solid #e2e8f0;border-radius:10px}
.flow-item.active{border-color:var(--tt-pink);background:rgba(254,44,85,.04)}
.flow-num{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;background:#f1f5f9;color:#64748b;flex-shrink:0}
.flow-item.active .flow-num{background:var(--tt-dark);color:#fff}
.flow-text{font-size:.85rem;font-weight:500;color:#475569}
.form-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem}
.form-card h3{font-size:1.05rem;font-weight:700;margin:0 0 .3rem;color:#1e293b;display:flex;align-items:center;gap:.4rem}
.form-card .form-desc{font-size:.85rem;color:#64748b;margin:0 0 1.2rem}
.pk-select-wrap{position:relative}
.pk-select-wrap select{width:100%;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit;background:#fff;appearance:none;-webkit-appearance:none;cursor:pointer}
.pk-select-wrap select:focus{outline:none;border-color:var(--tt-pink);box-shadow:0 0 0 3px rgba(254,44,85,.12)}
.pk-select-wrap::after{content:"\25BC";position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#94a3b8;pointer-events:none;font-size:.7rem}
.pk-handle-row{display:flex;align-items:center;gap:.5rem}
.pk-handle-prefix{font-size:1.1rem;color:#94a3b8;font-weight:600;flex-shrink:0}
.pk-handle-input{flex:1;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit}
.pk-handle-input:focus{outline:none;border-color:var(--tt-pink);box-shadow:0 0 0 3px rgba(254,44,85,.12)}
.pk-btn{background:var(--tt-dark);border:none;color:#fff;padding:.7rem 1.5rem;font-weight:700;border-radius:10px;cursor:pointer;font-family:inherit;font-size:.9rem;display:inline-flex;align-items:center;gap:.4rem}
.pk-btn:hover{opacity:.9;transform:translateY(-1px)}
.pk-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.tt-result-box{border-color:rgba(254,44,85,.25);background:rgba(254,44,85,.04); padding:15px; border-radius:10px;}
.tt-result-box .result-title{color:var(--tt-pink); margin-top:0;}
.history-table{width:100%;border-collapse:collapse;font-size:.85rem}
.history-table th{text-align:left;padding:.6rem .8rem;border-bottom:2px solid #e2e8f0;color:#64748b;font-weight:600;font-size:.78rem;text-transform:uppercase;letter-spacing:.03em}
.history-table th.ta-right{text-align:right}
.history-table td{padding:.6rem .8rem;border-bottom:1px solid #f1f5f9}
.history-table td.ta-right{text-align:right}
.history-table .cell-primary{font-weight:600;color:#1e293b}
.history-table .cell-sub{font-size:.78rem;color:#94a3b8;margin-top:2px}
.history-table tr:last-child td{border-bottom:none}

/* Batch CSS Updates */
.batch-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem;margin-top:1.5rem}
.batch-card h3{font-size:1.1rem;font-weight:700;color:#1e293b;margin:0 0 .3rem;display:flex;align-items:center;gap:.5rem}
.batch-list{max-height:320px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:1rem}
.batch-item{display:flex;align-items:center;gap:.8rem;padding:.65rem 1rem;border-bottom:1px solid #f1f5f9;font-size:.85rem;transition:background .15s}
.batch-item:last-child{border-bottom:none}
.batch-checkbox{width:18px;height:18px;cursor:pointer;}
.batch-item .batch-idx{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#f1f5f9;color:#64748b;font-size:.7rem;font-weight:700;flex-shrink:0}
.batch-item .batch-name{flex:1;font-weight:500;color:#1e293b}
.batch-item .batch-handle{color:#64748b;font-size:.8rem}
.batch-item .batch-status{width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.batch-item.done{background:#f0fdf4}
.batch-item.fail{background:#fef2f2}
.batch-item.active{background:rgba(254,44,85,.04)}
.batch-summary{display:flex;gap:1.5rem;flex-wrap:wrap;padding:.8rem 1rem;background:#f8fafc;border-radius:10px;font-size:.85rem;margin-top:1rem}
.batch-summary .stat{display:flex;align-items:center;gap:.3rem}
.batch-summary .stat-label{color:#64748b}
.batch-summary .stat-val{font-weight:700;color:#1e293b}
.badge-tt{display:inline-block;padding:2px 8px;border-radius:6px;font-size:.72rem;font-weight:600;background:var(--tt-pink);color:#fff;margin-right:4px}
@keyframes spin{to{transform:rotate(360deg)}}
.spinner-sm{width:16px;height:16px;border:2px solid rgba(254,44,85,.18);border-top-color:var(--tt-pink);border-radius:50%;animation:spin .8s linear infinite}
.batch-controls {display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; background:#f8fafc; padding:10px 15px; border-radius:10px; border:1px solid #e2e8f0;}
</style>

<div class="platform-card">
  <a href="scrape.php" class="platform-btn active-platform" style="background:var(--tt-dark);color:#fff">
    <div class="p-icon">&#9654;</div>
    <div class="p-title">TikTok</div>
    <div class="p-desc">Scrape semua video dari akun TikTok</div>
  </a>
  <a href="ig-scrape.php" class="platform-btn" style="background:linear-gradient(45deg,#833AB4,#FD1D1D,#F77737);color:#333">
    <div class="p-icon">&#9679;</div>
    <div class="p-title">Instagram</div>
    <div class="p-desc">Scrape semua post dari akun Instagram</div>
  </a>
</div>

<div class="flow-steps">
  <div class="flow-item active"><div class="flow-num">1</div><div class="flow-text">Pilih Mitra</div></div>
  <div class="flow-item"><div class="flow-num">2</div><div class="flow-text">Cek Handle TikTok</div></div>
  <div class="flow-item"><div class="flow-num">3</div><div class="flow-text">Scrape &amp; Simpan</div></div>
</div>

<div class="grid-2">
<div class="form-card">
  <h3><span class="badge-tt">TT</span> Scrape TikTok</h3>
  <p class="form-desc">Pilih mitra, handle TikTok auto-fill. Scrape semua video.</p>
  <?php if ($error): ?><div class="alert alert-danger" style="color:red; margin-bottom:15px;"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="scrape.php" id="tt-form">
    <?= csrf_field() ?>
    <div class="form-group" style="margin-bottom:15px;">
      <label for="mitra-select" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem; display:block;">Pilih Mitra</label>
      <div class="pk-select-wrap">
        <select id="mitra-select" name="mitra_name" required>
          <option value="">-- Pilih mitra --</option>
          <?php foreach ($brandGroups as $brand => $mitras): ?>
            <optgroup label="<?= e($brand) ?>">
            <?php foreach ($mitras as $m):
              $tt = $m['tt_handle'] !== '' ? '@'.$m['tt_handle'] : '(belum ada TikTok)';
            ?>
              <option value="<?= e($m['nama']) ?>" data-tt="<?= e($m['tt_handle']) ?>" <?= ($preMitra === $m['nama']) ? 'selected' : '' ?>>
                <?= e($m['nama']) ?> &mdash; <?= e($tt) ?>
              </option>
            <?php endforeach; ?>
            </optgroup>
          <?php endforeach; ?>
        </select>
      </div>
      <small class="form-hint" style="margin-top:.3rem; color:#64748b; font-size:0.8rem; display:block;">Mitra tanpa TikTok handle bisa dipilih &mdash; isi handle manual di bawah.</small>
    </div>
    <div class="form-group" style="margin-bottom:20px;">
      <label for="handle" style="font-weight:600;font-size:.85rem;margin-bottom:.4rem; display:block;">Handle TikTok</label>
      <div class="pk-handle-row">
        <span class="pk-handle-prefix">@</span>
        <input type="text" id="handle" name="handle" class="pk-handle-input" required placeholder="username_tiktok" value="<?= e($_POST['handle'] ?? $preHandle) ?>">
      </div>
    </div>
    <button type="submit" class="pk-btn" id="btn-scrape">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
      Scrape Semua Video
    </button>
  </form>

  <div class="scrape-overlay" id="scrape-overlay" style="display:none; text-align:center; padding:20px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:10px; margin-top:20px;">
    <div class="spinner-sm" style="margin:0 auto 10px;"></div>
    <div class="overlay-title" style="font-weight:bold; color:var(--tt-pink);">Mengambil semua video...</div>
    <div class="overlay-status" id="overlay-status" style="font-size:0.85rem; color:#64748b; margin-top:5px;">Menghubungi ScrapeCreators...</div>
    <div class="overlay-timer" style="font-size:0.8rem; font-weight:bold; margin-top:10px; background:#e2e8f0; display:inline-block; padding:4px 10px; border-radius:20px;">Waktu: <span id="overlay-timer">0</span> dtk</div>
  </div>

  <?php if ($result): ?>
  <div class="tt-result-box" style="margin-top:1.2rem">
    <h3 class="result-title">Hasil Scrape: @<?= e($result['handle']) ?></h3>
    <div class="result-meta" style="font-size:0.9rem; line-height:1.6;">
      <?php if ($result['mitra'] !== ''): ?><div><span style="color:#64748b;">Mitra:</span> <strong><?= e($result['mitra']) ?></strong></div><?php endif; ?>
      <div><span style="color:#64748b;">Akun:</span> <strong><?= e($result['nickname']) ?></strong></div>
      <div><span style="color:#64748b;">Video profil:</span> <strong><?= (int)$result['profile_total'] ?></strong></div>
      <div><span style="color:#64748b;">Terambil:</span> <strong><?= (int)$result['fetched'] ?></strong></div>
      <div><span style="color:#64748b;">Baru:</span> <strong style="color:green;"><?= (int)$result['inserted'] ?></strong></div>
      <div><span style="color:#64748b;">Total views:</span> <strong><?= number_format((int)$result['total_views']) ?></strong></div>
    </div>
    <?php if (!$result['complete']): ?><div class="alert alert-warning" style="margin-top:12px; font-size:0.85rem;">Pagination belum tuntas. Scrape ulang untuk lanjut.</div><?php endif; ?>
    <?php if (!$result['stopped_early'] && $result['fetched'] === 0): ?><div class="alert alert-info" style="margin-top:12px; font-size:0.85rem;">Tidak ada video baru.</div><?php endif; ?>
    <div style="margin-top:14px"><a href="akun.php?akun=<?= e($result['author_uid']) ?>" class="btn btn-ghost" style="font-size:0.85rem; text-decoration:underline;">Lihat Rekap Bulanan</a></div>
  </div>
  <?php endif; ?>
</div>

<div class="card form-card">
  <h2 style="font-size: 1.1rem; margin-top:0;">Riwayat Scrape</h2>
  <?php if (count($history) === 0): ?>
    <div class="empty">Belum ada scrape TikTok.</div>
  <?php else: ?>
    <div style="overflow-x:auto;">
    <table class="history-table">
      <thead><tr><th>Akun</th><th class="ta-right">Video</th><th class="ta-right">Views</th><th>Waktu</th></tr></thead>
      <tbody>
        <?php foreach ($history as $h): ?>
        <tr>
          <td><div class="cell-primary"><span class="badge-tt">TT</span>@<?= e($h['handle']) ?></div><div class="cell-sub"><?= e($h['mitra_name']) ?></div></td>
          <td class="ta-right"><strong><?= (int)$h['total_videos'] ?></strong></td>
          <td class="ta-right"><?= number_format((int)$h['total_views']) ?></td>
          <td class="cell-sub"><?= e(date('d M y H:i', strtotime($h['created_at']))) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  <?php endif; ?>
</div>
</div>

<?php if (count($ttAccounts) > 0): ?>
<div class="batch-card">
  <h3><span class="badge-tt">BATCH</span> Scrape Akun Pilihan</h3>
  <p style="font-size:.85rem;color:#64748b;margin:0 0 1rem">Pilih akun yang ingin di-scrape. Sistem akan otomatis memproses satu per satu dengan jeda aman.</p>
  
  <div class="batch-controls">
    <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-weight:600; font-size:0.9rem; color:#1e293b;">
        <input type="checkbox" id="check-all" class="batch-checkbox" checked> 
        Pilih Semua (<?= count($ttAccounts) ?> akun)
    </label>
    <button type="button" class="pk-btn" id="btn-batch" onclick="startBatch()">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      Mulai Scrape Akun Terpilih
    </button>
  </div>

  <div class="batch-list" id="batch-list">
    <?php $idx = 0; foreach ($ttAccounts as $acc): $idx++; ?>
    <div class="batch-item" id="batch-item-<?= $idx ?>" data-handle="<?= e($acc['tt_handle']) ?>" data-name="<?= e($acc['nama']) ?>">
      <input type="checkbox" class="batch-checkbox cb-item" data-target="<?= $idx ?>" checked>
      <div class="batch-idx"><?= $idx ?></div>
      <div class="batch-name"><?= e($acc['nama']) ?></div>
      <div class="batch-handle">@<?= e($acc['tt_handle']) ?></div>
      <div class="batch-status" id="batch-status-<?= $idx ?>" title="">-</div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="batch-summary" id="batch-summary" style="display:none">
    <div class="stat"><span class="stat-label">Terproses:</span><span class="stat-val"><span id="batch-current">0</span> / <span id="batch-total-selected">0</span></span></div>
    <div class="stat"><span class="stat-label">Selesai:</span><span class="stat-val" id="batch-done" style="color:#16a34a">0</span></div>
    <div class="stat"><span class="stat-label">Gagal:</span><span class="stat-val" id="batch-fail" style="color:#dc2626">0</span></div>
    <div class="stat"><span class="stat-label">Total video:</span><span class="stat-val" id="batch-videos">0</span></div>
  </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/layouts/footer.php'; ?>
<script>
(function(){
  // Auto-fill Mitra Select
  var sel = document.getElementById('mitra-select');
  var handleInput = document.getElementById('handle');
  if (sel && handleInput) {
    sel.addEventListener('change', function() {
      var opt = sel.options[sel.selectedIndex];
      var tt = opt ? opt.getAttribute('data-tt') : '';
      if (tt && tt !== '') { handleInput.value = tt; }
    });
  }

  // Loading Overlay Form Single
  var form = document.getElementById('tt-form');
  var overlay = document.getElementById('scrape-overlay');
  var timerEl = document.getElementById('overlay-timer');
  var btn = document.getElementById('btn-scrape');
  if (form && overlay) {
    form.addEventListener('submit', function(e) {
      if (!handleInput.value.trim()) { e.preventDefault(); return; }
      overlay.style.display = 'block';
      btn.disabled = true;
      btn.innerHTML = 'Sedang Memproses...';
      var sec = 0;
      setInterval(function() { sec++; if (timerEl) timerEl.textContent = sec; }, 1000);
    });
  }

  // LOGIKA BATCH SCRAPING BARU (Checkbox + Jeda)
  var checkAllBtn = document.getElementById('check-all');
  if (checkAllBtn) {
      checkAllBtn.addEventListener('change', function(e) {
          var checkboxes = document.querySelectorAll('.cb-item');
          checkboxes.forEach(function(cb) {
              cb.checked = e.target.checked;
          });
      });
  }

  window.startBatch = function() {
    // Ambil HANYA yang di-ceklis
    var checkedBoxes = document.querySelectorAll('.cb-item:checked');
    if (checkedBoxes.length === 0) {
        alert("Pilih minimal satu akun untuk di-scrape!");
        return;
    }

    // Siapkan element UI
    var btnBatch = document.getElementById('btn-batch');
    var summary = document.getElementById('batch-summary');
    var checkAll = document.getElementById('check-all');
    var allCheckboxes = document.querySelectorAll('.batch-checkbox');
    
    // Kunci UI
    btnBatch.disabled = true;
    btnBatch.textContent = 'Proses Batch Berjalan...';
    checkAll.disabled = true;
    allCheckboxes.forEach(cb => cb.disabled = true);
    summary.style.display = 'flex';
    document.getElementById('batch-total-selected').textContent = checkedBoxes.length;
    
    var csrf = document.querySelector('input[name="csrf_token"]');
    var csrfToken = csrf ? csrf.value : '';
    
    var done=0, fail=0, totalVideos=0, idx=0;
    
    // Buat Array antrean berdasarkan checkbox yang dipilih
    var queue = Array.from(checkedBoxes).map(function(cb) {
        var targetId = cb.getAttribute('data-target');
        return document.getElementById('batch-item-' + targetId);
    });

    function scrapeNext() {
      if (idx >= queue.length) {
        btnBatch.textContent = 'Selesai! ' + done + ' sukses, ' + fail + ' gagal';
        allCheckboxes.forEach(cb => cb.disabled = false);
        return;
      }
      
      var item = queue[idx];
      var handle = item.getAttribute('data-handle');
      var name = item.getAttribute('data-name');
      
      // Ambil ID dari data-target checkbox
      var checkbox = item.querySelector('.cb-item');
      var targetId = checkbox.getAttribute('data-target');
      var statusEl = document.getElementById('batch-status-' + targetId);
      
      // Animasi UI Sedang berjalan
      item.classList.add('active');
      statusEl.innerHTML = '<div class="spinner-sm"></div>';
      
      var fd = new FormData();
      fd.append('csrf_token', csrfToken);
      fd.append('handle', handle);
      fd.append('mitra_name', name);
      
      fetch('api/tiktok-batch-scrape.php', { method:'POST', body:fd })
        .then(function(r){ return r.json(); })
        .then(function(data){
          item.classList.remove('active');
          if (data.success) {
            item.classList.add('done');
            statusEl.innerHTML = '<span style="color:#16a34a;font-weight:700" title="Sukses">&#10003;</span>';
            done++; 
            totalVideos += (data.total_videos || 0); 
          } else {
            item.classList.add('fail');
            var errMessage = data.error || 'Gagal API';
            statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700" title="'+errMessage+'">&#10007;</span>';
            fail++;
          }
        }).catch(function(err){
          item.classList.remove('active');
          item.classList.add('fail');
          statusEl.innerHTML = '<span style="color:#dc2626;font-weight:700" title="Koneksi Error">&#10007;</span>';
          fail++;
        }).finally(function(){
          document.getElementById('batch-current').textContent = (idx + 1);
          document.getElementById('batch-done').textContent = done;
          document.getElementById('batch-fail').textContent = fail;
          document.getElementById('batch-videos').textContent = totalVideos;
          idx++; 
          
          // JEDA 2 DETIK SEBELUM LANJUT (Anti Banned / Limit Rate)
          if(idx < queue.length) {
              statusEl = document.getElementById('batch-status-' + queue[idx].querySelector('.cb-item').getAttribute('data-target'));
              statusEl.innerHTML = '<span style="font-size:0.7rem; color:#64748b;">Jeda..</span>';
              setTimeout(scrapeNext, 2000); 
          } else {
              scrapeNext(); // Panggil untuk menyudahi (idx >= queue.length)
          }
        });
    }
    
    // Mulai scraping antrean pertama
    scrapeNext();
  };
})();
</script>