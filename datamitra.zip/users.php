<?php
/**
 * users.php — Kelola user (khusus admin). Tambah/ubah role/nonaktifkan.
 */
require __DIR__ . '/config.php';
require_login();

if (!is_admin()) {
    redirect('index.php');
}

$pageTitle = 'Kelola User';
$active    = 'users';

$errors = [];
$me = (int)(current_user()['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $username = trim($_POST['username'] ?? '');
        $fullName = trim($_POST['full_name'] ?? '');
        $password = $_POST['password'] ?? '';
        $role     = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';

        if ($username === '' || $password === '') {
            $errors[] = 'Username dan password wajib diisi';
        } else {
            $stmt = db()->prepare('SELECT id FROM users WHERE username = ?');
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $errors[] = 'Username sudah dipakai';
            } else {
                db()->prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)')
                    ->execute([$username, password_hash($password, PASSWORD_DEFAULT), $fullName, $role]);
                flash('success', 'User "' . $username . '" ditambahkan');
                redirect('users.php');
            }
        }
    }

    if ($action === 'role') {
        $id       = (int)($_POST['id'] ?? 0);
        $role     = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        if ($id > 0 && $id !== $me) {
            db()->prepare('UPDATE users SET role = ? WHERE id = ?')->execute([$role, $id]);
            flash('success', 'Role user diperbarui');
        }
        redirect('users.php');
    }

    if ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0 && $id !== $me) {
            db()->prepare('UPDATE users SET is_active = 1 - is_active WHERE id = ?')->execute([$id]);
        }
        redirect('users.php');
    }
}

$users = db()->query('
    SELECT u.*, (SELECT COUNT(*) FROM videos v WHERE v.user_id = u.id) AS video_count
    FROM users u ORDER BY u.created_at
')->fetchAll();

require __DIR__ . '/layouts/header.php';
?>

<div class="grid-2">
    <div class="card">
        <h2 class="card-title">Tambah User</h2>
        <?php if (count($errors) > 0): ?>
            <div class="alert alert-danger"><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div>
        <?php endif; ?>
        <form method="post" action="users.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="full_name">Nama Lengkap</label>
                <input type="text" id="full_name" name="full_name" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control">
                    <option value="user">User (lihat data sendiri)</option>
                    <option value="admin">Admin (lihat semua)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Tambah User</button>
        </form>
    </div>

    <div class="card">
        <h2 class="card-title">Daftar User (<?= count($users) ?>)</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Role</th>
                    <th class="ta-right">Video</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td>
                        <div class="cell-primary"><?= e($u['full_name'] ?: $u['username']) ?><?= $u['id'] === $me ? ' <span class="cell-sub">(kamu)</span>' : '' ?></div>
                        <div class="cell-sub"><?= e($u['username']) ?></div>
                    </td>
                    <td>
                        <form method="post" action="users.php" class="inline-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="role">
                            <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                            <select name="role" class="form-control form-sm" <?= $u['id'] === $me ? 'disabled' : '' ?>>
                                <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                            <?php if ($u['id'] !== $me): ?><button type="submit" class="btn btn-ghost btn-sm">Simpan</button><?php endif; ?>
                        </form>
                    </td>
                    <td class="ta-right"><?= (int)$u['video_count'] ?></td>
                    <td>
                        <span class="badge <?= $u['is_active'] ? 'badge-success' : 'badge-muted' ?>"><?= $u['is_active'] ? 'Aktif' : 'Nonaktif' ?></span>
                    </td>
                    <td>
                        <?php if ($u['id'] !== $me): ?>
                            <form method="post" action="users.php" class="inline-form">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?= $u['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?> user ini?')"><?= $u['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/layouts/footer.php'; ?>