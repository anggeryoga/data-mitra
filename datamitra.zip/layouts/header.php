<?php
/**
 * layout/header.php — Header + sidebar
 * @var string $pageTitle
 */
require_once __DIR__ . '/../config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$pageTitle = $pageTitle ?? 'Dashboard';
$active    = $active ?? '';

function nav_item(string $href, string $label, string $key, string $active): string
{
    $isActive = $active === $key ? ' class="active"' : '';
    return '<a href="' . e($href) . '"' . $isActive . '>' . e($label) . '</a>';
}

$user = current_user();
?><!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> — <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="sidebar-brand">
            <span class="brand-logo">TA</span>
            <div>
                <strong><?= APP_NAME ?></strong>
                <small>TikTok Tracker</small>
            </div>
        </div>
        <nav class="sidebar-nav">
            <?= nav_item('index.php', 'Dashboard', 'dashboard', $active) ?>
            <?= nav_item('mitra.php', 'Direktori Mitra', 'mitra', $active) ?>
            <?= nav_item('scrape.php', 'Scrape TikTok', 'scrape', $active) ?>
            <?= nav_item('ig-scrape.php', 'Scrape Instagram', 'ig-scrape', $active) ?>
            <?= nav_item('input.php', 'Input Video', 'input', $active) ?>
            <?= nav_item('akun.php', 'Per Akun / Bulan', 'akun', $active) ?>
            <?php if (is_admin()): ?>
                <?= nav_item('users.php', 'Kelola User', 'users', $active) ?>
            <?php endif; ?>
        </nav>
        <div class="sidebar-footer">
            <div class="user-chip">
                <span class="user-avatar"><?= e(strtoupper(substr($user['full_name'] ?: $user['username'], 0, 1))) ?></span>
                <div>
                    <strong><?= e($user['full_name'] ?: $user['username']) ?></strong>
                    <small><?= is_admin() ? 'Admin' : 'User' ?></small>
                </div>
            </div>
            <a href="logout.php" class="btn btn-ghost btn-block">Keluar</a>
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <h1><?= e($pageTitle) ?></h1>
        </header>

        <?php foreach (get_flashes() as $f): ?>
            <div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
        <?php endforeach; ?>