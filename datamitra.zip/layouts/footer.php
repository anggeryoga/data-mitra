<footer class="footer">
            &copy; <?= date('Y') ?> <?= APP_NAME ?> — Data ditarik via ScrapeCreators &amp; TikWM
        </footer>
    </main>
</div>
</body>
</html>