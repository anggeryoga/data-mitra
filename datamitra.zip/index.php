<?php
/**
 * index.php — Dashboard lengkap: stat cards, matriks per akun per bulan, chart, top content.
 */
require __DIR__ . '/config.php';
require_login();

$pageTitle = 'Dashboard';
$active    = 'dashboard';

$isAdmin = is_admin();
$uid     = (int)(current_user()['id'] ?? 0);

// Scope data
$scopeWhere  = '';
$scopeParams = [];
if (!$isAdmin) {
    $scopeWhere  = ' AND v.user_id = ?';
    $scopeParams[] = $uid;
}

// Global stats
$igScopeWhere  = '';
$igScopeParams = [];
if (!$isAdmin) {
    $igScopeWhere  = ' AND p.user_id = ?';
    $igScopeParams[] = $uid;
}

$stmt = db()->prepare("
    SELECT COUNT(*) AS total_konten,
           COALESCE(SUM(play_count),0) AS total_views,
           COALESCE(SUM(digg_count),0) AS total_likes,
           COALESCE(SUM(comment_count),0) AS total_comments,
           COALESCE(SUM(share_count),0) AS total_shares,
           COUNT(DISTINCT author_unique_id) AS total_akun,
           COUNT(DISTINCT mitra_name) AS total_mitra
    FROM videos v WHERE 1=1 $scopeWhere
");
$stmt->execute($scopeParams);
$stat = $stmt->fetch();

// IG global stats
$stmt = db()->prepare("
    SELECT COUNT(*) AS total_ig_posts,
           COALESCE(SUM(like_count),0) AS total_ig_likes,
           COALESCE(SUM(comment_count),0) AS total_ig_comments,
           COALESCE(SUM(play_count),0) AS total_ig_plays,
           COUNT(DISTINCT ig_username) AS total_ig_akun
    FROM ig_posts p WHERE 1=1 $igScopeWhere
");
$stmt->execute($igScopeParams);
$igStat = $stmt->fetch();

// Engagement rate (global)
$engTotal = (int)$stat['total_views'];
$engInteraction = (int)$stat['total_likes'] + (int)$stat['total_comments'] + (int)$stat['total_shares'];
$engRate = $engTotal > 0 ? round(($engInteraction / $engTotal) * 100, 1) : 0;

// Rekap per akun per bulan (matriks)
$stmt = db()->prepare("
    SELECT v.author_unique_id,
           MAX(v.author_nickname) AS author_nickname,
           MAX(v.mitra_name) AS mitra_name,
           DATE_FORMAT(FROM_UNIXTIME(v.create_time), '%Y-%m') AS bulan,
           COUNT(*) AS jml_konten,
           COALESCE(SUM(v.play_count),0) AS total_views,
           COALESCE(SUM(v.digg_count),0) AS total_likes,
           COALESCE(SUM(v.comment_count),0) AS total_comments,
           COALESCE(SUM(v.share_count),0) AS total_shares
    FROM videos v
    WHERE v.author_unique_id <> '' $scopeWhere
    GROUP BY v.author_unique_id, bulan
    ORDER BY v.author_unique_id, bulan DESC
");
$stmt->execute($scopeParams);
$rows = $stmt->fetchAll();

// Susun matriks
$akunMap  = [];
$bulanSet = [];
foreach ($rows as $r) {
    $akun = $r['author_unique_id'];
    $bulan = $r['bulan'];
    $bulanSet[$bulan] = true;
    $akunMap[$akun]['nickname'] = $r['author_nickname'];
    $akunMap[$akun]['mitra'] = $r['mitra_name'] ?? '';
    $akunMap[$akun]['bulan'][$bulan] = [
        'jml'      => (int)$r['jml_konten'],
        'views'    => (int)$r['total_views'],
        'likes'    => (int)$r['total_likes'],
        'comments' => (int)$r['total_comments'],
        'shares'   => (int)$r['total_shares'],
    ];
}
$bulanList = array_keys($bulanSet);
rsort($bulanList);

// Totals per akun
foreach ($akunMap as $akun => &$a) {
    $a['total'] = 0; $a['total_views'] = 0; $a['total_likes'] = 0;
    $a['total_comments'] = 0; $a['total_shares'] = 0;
    foreach ($a['bulan'] as $b) {
        $a['total'] += $b['jml'];
        $a['total_views'] += $b['views'];
        $a['total_likes'] += $b['likes'];
        $a['total_comments'] += $b['comments'];
        $a['total_shares'] += $b['shares'];
    }
    $eng = $a['total_views'] > 0
        ? round((($a['total_likes'] + $a['total_comments'] + $a['total_shares']) / $a['total_views']) * 100, 1)
        : 0;
    $a['engagement'] = $eng;
}
unset($a);

// Sort by total_views desc
uasort($akunMap, fn($a, $b) => $b['total_views'] <=> $a['total_views']);

// Rekap global per bulan (chart data)
$stmt2 = db()->prepare("
    SELECT DATE_FORMAT(FROM_UNIXTIME(v.create_time), '%Y-%m') AS bulan,
           COUNT(*) AS jml_konten,
           COALESCE(SUM(v.play_count),0) AS total_views,
           COALESCE(SUM(v.digg_count),0) AS total_likes,
           COALESCE(SUM(v.comment_count),0) AS total_comments,
           COALESCE(SUM(v.share_count),0) AS total_shares
    FROM videos v
    WHERE v.author_unique_id <> '' $scopeWhere
    GROUP BY bulan
    ORDER BY bulan ASC
");
$stmt2->execute($scopeParams);
$monthlyStats = $stmt2->fetchAll();

// IG monthly stats (chart data)
$stmt2ig = db()->prepare("
    SELECT DATE_FORMAT(FROM_UNIXTIME(p.taken_at), '%Y-%m') AS bulan,
           COUNT(*) AS jml_posts,
           COALESCE(SUM(p.like_count),0) AS total_likes,
           COALESCE(SUM(p.comment_count),0) AS total_comments,
           COALESCE(SUM(p.play_count),0) AS total_plays
    FROM ig_posts p
    WHERE 1=1 $igScopeWhere
    GROUP BY bulan
    ORDER BY bulan ASC
");
$stmt2ig->execute($igScopeParams);
$igMonthlyStats = $stmt2ig->fetchAll();

// Top 10 content (highest views)
$stmt3 = db()->prepare("
    SELECT v.id, v.aweme_id, v.url, v.title, v.author_unique_id, v.mitra_name,
           v.create_time, v.play_count, v.digg_count, v.comment_count, v.share_count
    FROM videos v
    WHERE v.author_unique_id <> '' $scopeWhere
    ORDER BY v.play_count DESC
    LIMIT 10
");
$stmt3->execute($scopeParams);
$topContent = $stmt3->fetchAll();

// Top 10 IG posts (highest likes)
$stmt3ig = db()->prepare("
    SELECT p.id, p.ig_post_id, p.shortcode, p.url, p.caption, p.ig_username, p.mitra_name,
           p.taken_at, p.media_type, p.like_count, p.comment_count, p.play_count
    FROM ig_posts p
    WHERE 1=1 $igScopeWhere
    ORDER BY p.like_count DESC
    LIMIT 10
");
$stmt3ig->execute($igScopeParams);
$topIgContent = $stmt3ig->fetchAll();

require __DIR__ . '/layouts/header.php';
?>

<!-- Stat Cards -->
<div class="stat-grid">
    <div class="stat-card" style="border-left:3px solid #2563EB">
        <span class="stat-label">TikTok Konten</span>
        <span class="stat-value"><?= format_number((int)$stat['total_konten']) ?></span>
        <span class="stat-sub"><?= (int)$stat['total_akun'] ?> akun · <?= format_compact((int)$stat['total_views']) ?> views</span>
    </div>
    <div class="stat-card" style="border-left:3px solid #E1306C">
        <span class="stat-label">Instagram Posts</span>
        <span class="stat-value"><?= format_number((int)$igStat['total_ig_posts']) ?></span>
        <span class="stat-sub"><?= (int)$igStat['total_ig_akun'] ?> akun · <?= format_compact((int)$igStat['total_ig_likes']) ?> likes</span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Views (TT)</span>
        <span class="stat-value"><?= format_compact((int)$stat['total_views']) ?></span>
        <span class="stat-sub"><?= format_number((int)$stat['total_views']) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Likes (TT)</span>
        <span class="stat-value"><?= format_compact((int)$stat['total_likes']) ?></span>
        <span class="stat-sub"><?= format_number((int)$stat['total_likes']) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Engagement Rate</span>
        <span class="stat-value"><?= $engRate ?>%</span>
        <span class="stat-sub"><?= format_number($engInteraction) ?> interaksi</span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Mitra</span>
        <span class="stat-value"><?= (int)$stat['total_mitra'] ?></span>
        <span class="stat-sub">mitra unik</span>
    </div>
</div>

<?php if (!$isAdmin): ?>
    <div class="alert alert-info">Login sebagai <strong>User</strong>. Hanya data yang kamu input yang tampil.</div>
<?php endif; ?>

<!-- Monthly Chart -->
<?php if (count($monthlyStats) > 0): ?>
<div class="card">
    <div class="card-head">
        <h2 class="card-title">Tren Bulanan</h2>
        <span class="badge badge-info"><?= count($monthlyStats) ?> bulan</span>
    </div>
    <div class="chart-tabs" id="tt-chart-tabs">
        <button class="chart-tab active" data-metric="views">Views</button>
        <button class="chart-tab" data-metric="jml">Konten</button>
        <button class="chart-tab" data-metric="likes">Likes</button>
        <button class="chart-tab" data-metric="comments">Comments</button>
    </div>
    <div class="chart-bars" id="tt-chart-bars">
        <?php
        $maxVal = 1;
        foreach ($monthlyStats as $ms) { $v = (int)$ms['total_views']; if ($v > $maxVal) $maxVal = $v; }
        foreach ($monthlyStats as $ms):
            $v = (int)$ms['total_views'];
            $pct = $maxVal > 0 ? ($v / $maxVal) * 100 : 0;
        ?>
        <div class="chart-col"
             data-metric="views" data-value="<?= $v ?>"
             data-metric2="jml" data-value2="<?= (int)$ms['jml_konten'] ?>"
             data-metric3="likes" data-value3="<?= (int)$ms['total_likes'] ?>"
             data-metric4="comments" data-value4="<?= (int)$ms['total_comments'] ?>">
            <div class="chart-val"><?= format_compact($v) ?></div>
            <div class="chart-bar" style="height:<?= max($pct, 2) ?>%"></div>
            <div class="chart-label"><?= e(date('M', strtotime($ms['bulan'] . '-01'))) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Main Matrix Table -->
<div class="card">
    <div class="card-head">
        <h2 class="card-title">Konten per Akun per Bulan</h2>
        <?php if (count($akunMap) > 0): ?>
            <span class="badge badge-success"><?= count($akunMap) ?> akun</span>
        <?php endif; ?>
    </div>
    <?php if (count($akunMap) === 0): ?>
        <div class="empty">Belum ada data. <a href="scrape.php">Scrape akun TikTok</a> dulu.</div>
    <?php else: ?>
        <div class="table-scroll">
            <table class="table">
                <thead>
                    <tr>
                        <th>Akun</th>
                        <?php foreach ($bulanList as $b): ?>
                            <th class="ta-right"><?= e(date('M Y', strtotime($b . '-01'))) ?></th>
                        <?php endforeach; ?>
                        <th class="ta-right">Konten</th>
                        <th class="ta-right">Views</th>
                        <th class="ta-right">Likes</th>
                        <th class="ta-right">Komen</th>
                        <th class="ta-right">Share</th>
                        <th class="ta-right">Eng. Rate</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($akunMap as $akun => $a): ?>
                    <tr>
                        <td>
                            <div class="cell-primary">@<?= e($akun) ?></div>
                            <?php if (!empty($a['mitra'])): ?>
                                <div class="cell-sub mitra-tag"><?= e($a['mitra']) ?></div>
                            <?php endif; ?>
                        </td>
                        <?php foreach ($bulanList as $b): ?>
                            <td class="ta-right">
                                <?php if (isset($a['bulan'][$b])):
                                    $bd = $a['bulan'][$b];
                                ?>
                                    <strong><?= (int)$bd['jml'] ?></strong>
                                    <div class="cell-sub"><?= format_compact((int)$bd['views']) ?> views</div>
                                <?php else: ?>
                                    <span class="cell-sub">—</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                        <td class="ta-right"><strong><?= (int)$a['total'] ?></strong></td>
                        <td class="ta-right"><?= format_compact((int)$a['total_views']) ?></td>
                        <td class="ta-right"><?= format_compact((int)$a['total_likes']) ?></td>
                        <td class="ta-right"><?= format_compact((int)$a['total_comments']) ?></td>
                        <td class="ta-right"><?= format_compact((int)$a['total_shares']) ?></td>
                        <td class="ta-right">
                            <span class="badge <?= $a['engagement'] >= 5 ? 'badge-success' : ($a['engagement'] >= 2 ? 'badge-info' : 'badge-muted') ?>">
                                <?= $a['engagement'] ?>%
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Top Content TikTok -->
<?php if (count($topContent) > 0): ?>
<div class="card">
    <div class="card-head">
        <h2 class="card-title">Top 10 Konten TikTok (Views Tertinggi)</h2>
    </div>
    <div class="table-scroll">
        <table class="table">
            <thead>
                <tr>
                    <th style="width:36px">#</th>
                    <th>Video</th>
                    <th>Akun</th>
                    <th>Tanggal</th>
                    <th class="ta-right">Views</th>
                    <th class="ta-right">Likes</th>
                    <th class="ta-right">Komen</th>
                    <th class="ta-right">Share</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($topContent as $i => $tc): ?>
                <tr>
                    <td class="cell-sub"><strong><?= $i + 1 ?></strong></td>
                    <td>
                        <a href="<?= e($tc['url']) ?>" target="_blank" rel="noopener" class="cell-primary">
                            <?= e(mb_strimwidth((string)($tc['title'] ?: '(tanpa deskripsi)'), 0, 60, '…')) ?>
                        </a>
                    </td>
                    <td>
                        <strong>@<?= e($tc['author_unique_id']) ?></strong>
                        <?php if ($tc['mitra_name'] !== ''): ?>
                            <div class="cell-sub"><?= e($tc['mitra_name']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="cell-sub"><?= e(date('d M Y', (int)$tc['create_time'])) ?></td>
                    <td class="ta-right"><strong><?= format_number((int)$tc['play_count']) ?></strong></td>
                    <td class="ta-right"><?= format_number((int)$tc['digg_count']) ?></td>
                    <td class="ta-right"><?= format_number((int)$tc['comment_count']) ?></td>
                    <td class="ta-right"><?= format_number((int)$tc['share_count']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- IG Monthly Chart -->
<?php if (count($igMonthlyStats) > 0): ?>
<div class="card">
    <div class="card-head">
        <h2 class="card-title">Tren Bulanan Instagram</h2>
        <span class="badge badge-info"><?= count($igMonthlyStats) ?> bulan</span>
    </div>
    <div class="chart-tabs" id="ig-chart-tabs">
        <button class="chart-tab active" data-metric="likes">Likes</button>
        <button class="chart-tab" data-metric="posts">Posts</button>
        <button class="chart-tab" data-metric="comments">Comments</button>
        <button class="chart-tab" data-metric="plays">Plays</button>
    </div>
    <div class="chart-bars" id="ig-chart-bars">
        <?php
        $igMaxVal = 1;
        foreach ($igMonthlyStats as $ms) { $v = (int)$ms['total_likes']; if ($v > $igMaxVal) $igMaxVal = $v; }
        foreach ($igMonthlyStats as $ms):
            $v = (int)$ms['total_likes'];
            $pct = $igMaxVal > 0 ? ($v / $igMaxVal) * 100 : 0;
        ?>
        <div class="chart-col"
             data-metric="likes" data-value="<?= $v ?>"
             data-metric2="posts" data-value2="<?= (int)$ms['jml_posts'] ?>"
             data-metric3="comments" data-value3="<?= (int)$ms['total_comments'] ?>"
             data-metric4="plays" data-value4="<?= (int)$ms['total_plays'] ?>">
            <div class="chart-val"><?= format_compact($v) ?></div>
            <div class="chart-bar" style="height:<?= max($pct, 2) ?>%;background:linear-gradient(180deg,#833AB4 0%,#FD1D1D 50%,#F77737 100%)"></div>
            <div class="chart-label"><?= e(date('M', strtotime($ms['bulan'] . '-01'))) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Top IG Content -->
<?php if (count($topIgContent) > 0): ?>
<div class="card">
    <div class="card-head">
        <h2 class="card-title">Top 10 Konten Instagram (Likes Tertinggi)</h2>
    </div>
    <div class="table-scroll">
        <table class="table">
            <thead>
                <tr>
                    <th style="width:36px">#</th>
                    <th>Post</th>
                    <th>Akun IG</th>
                    <th>Tipe</th>
                    <th>Tanggal</th>
                    <th class="ta-right">Likes</th>
                    <th class="ta-right">Komen</th>
                    <th class="ta-right">Plays</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $igTypeLabels = [1 => 'Foto', 2 => 'Video', 8 => 'Carousel'];
            foreach ($topIgContent as $i => $tc): ?>
                <tr>
                    <td class="cell-sub"><strong><?= $i + 1 ?></strong></td>
                    <td>
                        <a href="<?= $tc['shortcode'] ? 'https://www.instagram.com/p/' . e($tc['shortcode']) : e($tc['url']) ?>" target="_blank" rel="noopener" class="cell-primary">
                            <?= e(mb_strimwidth((string)($tc['caption'] ?: '(tanpa caption)'), 0, 60, '…')) ?>
                        </a>
                    </td>
                    <td>
                        <strong>@<?= e($tc['ig_username']) ?></strong>
                        <?php if ($tc['mitra_name'] !== ''): ?>
                            <div class="cell-sub"><?= e($tc['mitra_name']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-info"><?= e($igTypeLabels[(int)$tc['media_type']] ?? 'Lain') ?></span></td>
                    <td class="cell-sub"><?= e(date('d M Y', (int)$tc['taken_at'])) ?></td>
                    <td class="ta-right"><strong><?= format_number((int)$tc['like_count']) ?></strong></td>
                    <td class="ta-right"><?= format_number((int)$tc['comment_count']) ?></td>
                    <td class="ta-right"><?= format_number((int)$tc['play_count']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<script>
// Generic chart tab switching — scoped per tab group + chart container
(function() {
    function initChart(tabContainerId, chartContainerId, metricMap) {
        var tabContainer = document.getElementById(tabContainerId);
        var chartContainer = document.getElementById(chartContainerId);
        if (!tabContainer || !chartContainer) return;

        var tabs = tabContainer.querySelectorAll('.chart-tab');
        var cols = chartContainer.querySelectorAll('.chart-col');
        if (!tabs.length || !cols.length) return;

        function renderChart(metric) {
            var dataKey = metricMap[metric] || 'value';
            var max = 1;
            cols.forEach(function(c) {
                var v = parseInt(c.dataset[dataKey]) || 0;
                if (v > max) max = v;
            });
            cols.forEach(function(c) {
                var v = parseInt(c.dataset[dataKey]) || 0;
                var pct = max > 0 ? (v / max) * 100 : 0;
                c.querySelector('.chart-bar').style.height = Math.max(pct, 2) + '%';
                var label = v >= 1000 ? (v >= 1000000 ? (v/1000000).toFixed(1)+'M' : Math.round(v/1000)+'K') : v;
                c.querySelector('.chart-val').textContent = label;
            });
        }

        tabs.forEach(function(t) {
            t.addEventListener('click', function() {
                tabs.forEach(function(x) { x.classList.remove('active'); });
                t.classList.add('active');
                renderChart(t.dataset.metric);
            });
        });
    }

    // TikTok chart: views, jml, likes, comments → mapped to data attributes value, value2, value3, value4
    initChart('tt-chart-tabs', 'tt-chart-bars', {
        views: 'value',
        jml: 'value2',
        likes: 'value3',
        comments: 'value4'
    });

    // IG chart: likes, posts, comments, plays → mapped to data attributes value, value2, value3, value4
    initChart('ig-chart-tabs', 'ig-chart-bars', {
        likes: 'value',
        posts: 'value2',
        comments: 'value3',
        plays: 'value4'
    });
})();
</script>

<?php require __DIR__ . "/layouts/footer.php"; ?>
