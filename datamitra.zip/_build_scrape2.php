<?php
$f = __DIR__ . '/scrape.php';
$h = '?>' . "\n";
$h .= '<style>' . "\n";
$h .= ':root{--tt-dark:#0f172a;--tt-pink:#FE2C55;--tt-cyan:#25F4EE}' . "\n";
// shared platform card styles (same as ig-scrape)
$h .= '.platform-card{display:flex;gap:1rem;margin-bottom:1.5rem}' . "\n";
$h .= '.platform-btn{flex:1;padding:1.2rem;border-radius:12px;text-align:center;text-decoration:none!important;border:2px solid transparent;transition:transform .12s,box-shadow .12s}' . "\n";
$h .= '.platform-btn:hover{transform:translateY(-2px);box-shadow:0 4px 16px rgba(0,0,0,.1)}' . "\n";
$h .= '.platform-btn.active-platform{box-shadow:0 2px 12px rgba(0,0,0,.12);border-color:rgba(255,255,255,.3)}' . "\n";
$h .= '.platform-btn .p-icon{font-size:1.5rem;margin-bottom:.3rem}' . "\n";
$h .= '.platform-btn .p-title{font-weight:700;font-size:1.05rem}' . "\n";
$h .= '.platform-btn .p-desc{font-size:.78rem;opacity:.8;margin-top:.2rem}' . "\n";
// flow steps
$h .= '.flow-steps{display:flex;gap:.5rem;margin-bottom:1.5rem}' . "\n";
$h .= '.flow-item{flex:1;display:flex;align-items:center;gap:.6rem;padding:.8rem 1rem;background:#fff;border:1px solid #e2e8f0;border-radius:10px}' . "\n";
$h .= '.flow-item.active{border-color:var(--tt-pink);background:rgba(254,44,85,.04)}' . "\n";
$h .= '.flow-num{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;background:#f1f5f9;color:#64748b;flex-shrink:0}' . "\n";
$h .= '.flow-item.active .flow-num{background:var(--tt-dark);color:#fff}' . "\n";
$h .= '.flow-text{font-size:.85rem;font-weight:500;color:#475569}' . "\n";
// form card
$h .= '.form-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem}' . "\n";
$h .= '.form-card h3{font-size:1.05rem;font-weight:700;margin:0 0 .3rem;color:#1e293b;display:flex;align-items:center;gap:.4rem}' . "\n";
$h .= '.form-card .form-desc{font-size:.85rem;color:#64748b;margin:0 0 1.2rem}' . "\n";
// select wrap
$h .= '.pk-select-wrap{position:relative}' . "\n";
$h .= '.pk-select-wrap select{width:100%;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit;background:#fff;appearance:none;-webkit-appearance:none;cursor:pointer}' . "\n";
$h .= '.pk-select-wrap select:focus{outline:none;border-color:var(--tt-pink);box-shadow:0 0 0 3px rgba(254,44,85,.12)}' . "\n";
$h .= '.pk-select-wrap::after{content:"\25BC";position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#94a3b8;pointer-events:none;font-size:.7rem}' . "\n";
// handle input
$h .= '.pk-handle-row{display:flex;align-items:center;gap:.5rem}' . "\n";
$h .= '.pk-handle-prefix{font-size:1.1rem;color:#94a3b8;font-weight:600;flex-shrink:0}' . "\n";
$h .= '.pk-handle-input{flex:1;padding:.65rem .8rem;border:1px solid #d1d5db;border-radius:10px;font-size:.88rem;font-family:inherit}' . "\n";
$h .= '.pk-handle-input:focus{outline:none;border-color:var(--tt-pink);box-shadow:0 0 0 3px rgba(254,44,85,.12)}' . "\n";
// buttons
$h .= '.pk-btn{background:var(--tt-dark);border:none;color:#fff;padding:.7rem 1.5rem;font-weight:700;border-radius:10px;cursor:pointer;font-family:inherit;font-size:.9rem;display:inline-flex;align-items:center;gap:.4rem}' . "\n";
$h .= '.pk-btn:hover{opacity:.9;transform:translateY(-1px)}' . "\n";
$h .= '.pk-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}' . "\n";
// result box
$h .= '.tt-result-box{border-color:rgba(254,44,85,.25);background:rgba(254,44,85,.04)}' . "\n";
$h .= '.tt-result-box .result-title{color:var(--tt-pink)}' . "\n";
// history table (shared with ig-scrape)
$h .= '.history-table{width:100%;border-collapse:collapse;font-size:.85rem}' . "\n";
$h .= '.history-table th{text-align:left;padding:.6rem .8rem;border-bottom:2px solid #e2e8f0;color:#64748b;font-weight:600;font-size:.78rem;text-transform:uppercase;letter-spacing:.03em}' . "\n";
$h .= '.history-table th.ta-right{text-align:right}' . "\n";
$h .= '.history-table td{padding:.6rem .8rem;border-bottom:1px solid #f1f5f9}' . "\n";
$h .= '.history-table td.ta-right{text-align:right}' . "\n";
$h .= '.history-table .cell-primary{font-weight:600;color:#1e293b}' . "\n";
$h .= '.history-table .cell-sub{font-size:.78rem;color:#94a3b8;margin-top:2px}' . "\n";
$h .= '.history-table tr:last-child td{border-bottom:none}' . "\n";
// batch
$h .= '.batch-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:1.5rem;margin-top:1.5rem}' . "\n";
$h .= '.batch-card h3{font-size:1.1rem;font-weight:700;color:#1e293b;margin:0 0 .3rem;display:flex;align-items:center;gap:.5rem}' . "\n";
$h .= '.batch-list{max-height:320px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:1rem}' . "\n";
$h .= '.batch-item{display:flex;align-items:center;gap:.8rem;padding:.65rem 1rem;border-bottom:1px solid #f1f5f9;font-size:.85rem;transition:background .15s}' . "\n";
$h .= '.batch-item:last-child{border-bottom:none}' . "\n";
$h .= '.batch-item .batch-idx{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#f1f5f9;color:#64748b;font-size:.7rem;font-weight:700;flex-shrink:0}' . "\n";
$h .= '.batch-item .batch-name{flex:1;font-weight:500;color:#1e293b}' . "\n";
$h .= '.batch-item .batch-handle{color:#64748b;font-size:.8rem}' . "\n";
$h .= '.batch-item .batch-status{width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex-shrink:0}' . "\n";
$h .= '.batch-item.done{background:#f0fdf4}' . "\n";
$h .= '.batch-item.fail{background:#fef2f2}' . "\n";
$h .= '.batch-item.active{background:rgba(254,44,85,.04)}' . "\n";
$h .= '.batch-summary{display:flex;gap:1.5rem;flex-wrap:wrap;padding:.8rem 1rem;background:#f8fafc;border-radius:10px;font-size:.85rem;margin-top:1rem}' . "\n";
$h .= '.batch-summary .stat{display:flex;align-items:center;gap:.3rem}' . "\n";
$h .= '.batch-summary .stat-label{color:#64748b}' . "\n";
$h .= '.batch-summary .stat-val{font-weight:700;color:#1e293b}' . "\n";
// badges
$h .= '.badge-tt{display:inline-block;padding:2px 8px;border-radius:6px;font-size:.72rem;font-weight:600;background:var(--tt-pink);color:#fff;margin-right:4px}' . "\n";
$h .= '@keyframes spin{to{transform:rotate(360deg)}}' . "\n";
$h .= '.spinner-sm{width:16px;height:16px;border:2px solid rgba(254,44,85,.18);border-top-color:var(--tt-pink);border-radius:50%;animation:spin .8s linear infinite}' . "\n";
$h .= '</style>' . "\n";

file_put_contents($f, file_get_contents($f) . $h);
echo "CSS appended: " . filesize($f) . "\n";
